import { PantryScanner } from "@/components/pantry-scanner";

export default function PantryPage() {
  return <PantryScanner />;
}