import { MealCalendar } from "@/components/meal-calendar";

export default function MealPlanningPage() {
  return (
    <div className="h-screen bg-slate-50">
      <MealCalendar />
    </div>
  );
}