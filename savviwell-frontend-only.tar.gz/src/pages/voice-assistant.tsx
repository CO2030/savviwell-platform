import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { VoiceChat } from "@/components/voice-chat";
import { NutritionPanel } from "@/components/nutrition-panel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Menu, Bell } from "lucide-react";

export default function VoiceAssistantPage() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data: conversations } = useQuery({
    queryKey: ["/api/conversations"],
  });

  const { data: user } = useQuery({
    queryKey: ["/api/user"],
  });

  // Create initial conversation if none exists
  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conversations", {
        title: "Health & Nutrition Chat",
        lastMessage: null,
      });
      return response.json();
    },
    onSuccess: (newConversation) => {
      setCurrentConversationId(newConversation.id);
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  // Set current conversation or create one
  useEffect(() => {
    if (conversations && conversations.length > 0 && !currentConversationId) {
      setCurrentConversationId(conversations[0].id);
    } else if (conversations && conversations.length === 0 && !createConversationMutation.isPending) {
      createConversationMutation.mutate();
    }
  }, [conversations, currentConversationId]);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden">
          <div className="fixed inset-y-0 left-0 w-80 bg-white shadow-xl">
            <Sidebar className="w-full h-full" />
            <button
              onClick={() => setIsSidebarOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <Sidebar className="hidden lg:flex lg:w-80" />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 p-4 lg:p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setIsSidebarOpen(true)}
              >
                <Menu className="h-5 w-5 text-slate-600" />
              </Button>
              <div>
                <h2 className="text-xl font-semibold text-slate-800">AI Assistant</h2>
                <p className="text-sm text-slate-500">
                  Ask me anything about your health and nutrition
                </p>
              </div>
            </div>

            {/* Status Indicators */}
            <div className="flex items-center space-x-3">
              <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mr-2" />
                AI Online
              </Badge>
              <Button variant="ghost" size="icon">
                <Bell className="h-4 w-4 text-slate-600" />
              </Button>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-hidden flex">
          {/* Conversation View */}
          {currentConversationId ? (
            <VoiceChat conversationId={currentConversationId} />
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <p className="text-slate-500">Starting your assistant...</p>
            </div>
          )}

          {/* Right Sidebar - Nutrition Panel */}
          <NutritionPanel />
        </div>
      </div>
    </div>
  );
}