import { FamilyProfiles } from "@/components/family-profiles";

export default function FamilyProfilesPage() {
  return <FamilyProfiles />;
}