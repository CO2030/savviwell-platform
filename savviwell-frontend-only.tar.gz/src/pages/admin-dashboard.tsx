import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Users, MessageSquare, Activity, TrendingUp, Mail, Download, Target, BarChart3 } from "lucide-react";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();

  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const { data: recentSignups, isLoading: signupsLoading } = useQuery({
    queryKey: ["/api/admin/signups"],
    queryFn: () => fetch("/api/admin/signups?days=30").then(res => res.json()),
  });

  const { data: familySignups, isLoading: familySignupsLoading } = useQuery({
    queryKey: ["/api/admin/family-signups"],
  });

  const handleLogout = () => {
    setLocation("/admin/login");
  };

    const marketingUsers = [{
        user: {
            name: 'test user',
            email: 'test@email.com',
        },
        onboarding: {
            newsletterSubscribed: true,
            marketingConsent: true,
            signupSource: 'google',
            householdSize: 4,
            signupDate: new Date()
        }
    }]

  const handleExportCSV = () => {
    console.log('export csv')
  };

  const handleTargetedSegment = (segment) => {
    console.log('handle targeted segment', segment)
  };


  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">A</span>
              </div>
              <span className="ml-2 text-xl font-semibold">Admin Dashboard</span>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="marketing">Marketing</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "..." : stats?.totalUsers || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Registered users
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Conversations</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "..." : stats?.totalConversations || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Total chat sessions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "..." : stats?.activeUsers || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Active in last 30 days
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Newsletter Subscribers</CardTitle>
                  <Mail className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "..." : stats?.marketingStats?.newsletterSubscribers || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Opted in for marketing
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {isLoading ? (
                    <div className="text-center text-muted-foreground">Loading...</div>
                  ) : stats?.recentActivity?.length ? (
                    stats.recentActivity.map((activity, index) => (
                      <div key={index} className="flex items-center space-x-4">
                        <div className={`w-2 h-2 rounded-full ${
                          activity.type === 'conversation' ? 'bg-blue-500' :
                          activity.type === 'nutrition' ? 'bg-green-500' :
                          activity.type === 'meal_plan' ? 'bg-purple-500' :
                          'bg-gray-500'
                        }`}></div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{activity.description}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(activity.timestamp).toLocaleDateString()} at{' '}
                            {new Date(activity.timestamp).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-muted-foreground">No recent activity</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="marketing" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Signup Sources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {stats?.marketingStats?.signupsBySource && Object.entries(stats.marketingStats.signupsBySource).map(([source, count]) => (
                      <div key={source} className="flex justify-between items-center">
                        <span className="text-sm capitalize">{source}</span>
                        <Badge variant="secondary">{count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Top Goals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {stats?.marketingStats?.topGoals?.map((goal, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-sm capitalize">{goal.goal.replace('_', ' ')}</span>
                        <Badge variant="secondary">{goal.count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Engagement</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Completed Onboarding</span>
                      <span className="font-medium">{stats?.marketingStats?.completedOnboarding || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Avg Household Size</span>
                      <span className="font-medium">{stats?.marketingStats?.averageHouseholdSize || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Active Users (30d)</span>
                      <span className="font-medium">{stats?.marketingStats?.activeUsers30Days || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>User List</CardTitle>
                <div className="flex gap-2">
                  <Button onClick={handleExportCSV} size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {marketingUsers?.map((user, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{user.user.name}</p>
                        <p className="text-sm text-muted-foreground">{user.user.email}</p>
                        <div className="flex gap-2 mt-1">
                          {user.onboarding.newsletterSubscribed && <Badge variant="secondary">Newsletter</Badge>}
                          {user.onboarding.marketingConsent && <Badge variant="secondary">Marketing OK</Badge>}
                          <Badge variant="outline">{user.onboarding.signupSource}</Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm">{user.onboarding.householdSize} members</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(user.onboarding.signupDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Reports</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    variant="outline" 
                    onClick={() => handleTargetedSegment({ hasNewsletter: 'true' })}
                    className="w-full justify-start"
                  >
                    <Target className="h-4 w-4 mr-2" />
                    Newsletter Subscribers Only
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleTargetedSegment({ goal: 'family_nutrition' })}
                    className="w-full justify-start"
                  >
                    <Target className="h-4 w-4 mr-2" />
                    Family Nutrition Focused Users
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleTargetedSegment({ householdSize: '3' })}
                    className="w-full justify-start"
                  >
                    <Target className="h-4 w-4 mr-2" />
                    Large Households (3+ members)
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Export Options</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={handleExportCSV}
                    className="w-full justify-start"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Complete User Database (CSV)
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => window.open("/api/admin/marketing/newsletter-subscribers", "_blank")}
                    className="w-full justify-start"
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Newsletter Subscriber List (JSON)
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => window.open("/api/admin/stats", "_blank")}
                    className="w-full justify-start"
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Analytics Summary (JSON)
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}