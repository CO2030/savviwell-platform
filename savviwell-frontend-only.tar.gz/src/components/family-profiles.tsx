import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Users, Plus, Edit, Heart, AlertTriangle, Utensils, Activity, MoreVertical, Archive, Share, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface FamilyProfile {
  user: {
    id: number;
    name: string;
    profileImage: string | null;
    isMainAccount: boolean;
  };
  profile: {
    id: number;
    age: number | null;
    gender: string | null;
    dailyCalorieGoal: number;
    healthGoals: string[];
    dietaryRestrictions: string[];
    allergies: string[];
    dislikes: string[];
    favorites: string[];
    activityLevel: string;
    medicalConditions: string[];
  };
}

export function FamilyProfiles() {
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<FamilyProfile | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    dailyCalorieGoal: "2000",
    healthGoals: "",
    dietaryRestrictions: "",
    allergies: "",
    dislikes: "",
    favorites: "",
    activityLevel: "moderate",
    medicalConditions: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: familyProfiles = [], isLoading } = useQuery({
    queryKey: ["/api/family/profiles"],
  });

  const createMemberMutation = useMutation({
    mutationFn: async (memberData: any) => {
      return apiRequest("POST", "/api/family/members", memberData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/family/profiles"] });
      setIsAddingMember(false);
      resetForm();
      toast({
        title: "Family member added",
        description: "New family member has been successfully added to your profile.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add family member. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async ({ userId, data }: { userId: number; data: any }) => {
      return apiRequest("PATCH", `/api/profiles/${userId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/family/profiles"] });
      setSelectedProfile(null);
      toast({
        title: "Profile updated",
        description: "Family member profile has been successfully updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      age: "",
      gender: "",
      dailyCalorieGoal: "2000",
      healthGoals: "",
      dietaryRestrictions: "",
      allergies: "",
      dislikes: "",
      favorites: "",
      activityLevel: "moderate",
      medicalConditions: ""
    });
  };

  const handleAddMember = () => {
    const arrayFields = ['healthGoals', 'dietaryRestrictions', 'allergies', 'dislikes', 'favorites', 'medicalConditions'];
    const processedData = { ...formData };
    
    arrayFields.forEach(field => {
      processedData[field] = processedData[field]
        .split(',')
        .map(item => item.trim())
        .filter(item => item.length > 0);
    });

    createMemberMutation.mutate({
      name: formData.name,
      age: formData.age ? parseInt(formData.age) : undefined,
      userId: 0, // Will be set by backend
      gender: formData.gender || null,
      dailyCalorieGoal: parseInt(formData.dailyCalorieGoal),
      healthGoals: processedData.healthGoals,
      dietaryRestrictions: processedData.dietaryRestrictions,
      allergies: processedData.allergies,
      dislikes: processedData.dislikes,
      favorites: processedData.favorites,
      activityLevel: formData.activityLevel,
      medicalConditions: processedData.medicalConditions
    });
  };

  const handleUpdateProfile = () => {
    if (!selectedProfile) return;

    const arrayFields = ['healthGoals', 'dietaryRestrictions', 'allergies', 'dislikes', 'favorites', 'medicalConditions'];
    const processedData = { ...formData };
    
    arrayFields.forEach(field => {
      processedData[field] = processedData[field]
        .split(',')
        .map(item => item.trim())
        .filter(item => item.length > 0);
    });

    updateProfileMutation.mutate({
      userId: selectedProfile.user.id,
      data: {
        age: formData.age ? parseInt(formData.age) : null,
        gender: formData.gender || null,
        dailyCalorieGoal: parseInt(formData.dailyCalorieGoal),
        healthGoals: processedData.healthGoals,
        dietaryRestrictions: processedData.dietaryRestrictions,
        allergies: processedData.allergies,
        dislikes: processedData.dislikes,
        favorites: processedData.favorites,
        activityLevel: formData.activityLevel,
        medicalConditions: processedData.medicalConditions
      }
    });
  };

  const openEditDialog = (profile: FamilyProfile) => {
    setSelectedProfile(profile);
    setFormData({
      name: profile.user.name,
      age: profile.profile.age?.toString() || "",
      gender: profile.profile.gender || "",
      dailyCalorieGoal: profile.profile.dailyCalorieGoal.toString(),
      healthGoals: profile.profile.healthGoals.join(', '),
      dietaryRestrictions: profile.profile.dietaryRestrictions.join(', '),
      allergies: profile.profile.allergies.join(', '),
      dislikes: profile.profile.dislikes.join(', '),
      favorites: profile.profile.favorites.join(', '),
      activityLevel: profile.profile.activityLevel,
      medicalConditions: profile.profile.medicalConditions.join(', ')
    });
  };

  if (isLoading) {
    return <div className="p-6">Loading family profiles...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-blue-600" />
          <h2 className="text-2xl font-semibold">Family Profiles</h2>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Archive className="h-4 w-4 mr-2" />
                Export Profiles
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Share className="h-4 w-4 mr-2" />
                Share Family Info
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Edit className="h-4 w-4 mr-2" />
                Family Settings
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Dialog open={isAddingMember} onOpenChange={setIsAddingMember}>
            <DialogTrigger asChild>
              <Button onClick={() => setIsAddingMember(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Family Member
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Family Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter name"
                  />
                </div>
                <div>
                  <Label>Age</Label>
                  <Input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    placeholder="Enter age"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Gender</Label>
                  <Select value={formData.gender} onValueChange={(value) => setFormData(prev => ({ ...prev, gender: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Daily Calorie Goal</Label>
                  <Input
                    type="number"
                    value={formData.dailyCalorieGoal}
                    onChange={(e) => setFormData(prev => ({ ...prev, dailyCalorieGoal: e.target.value }))}
                  />
                </div>
              </div>

              <div>
                <Label>Activity Level</Label>
                <Select value={formData.activityLevel} onValueChange={(value) => setFormData(prev => ({ ...prev, activityLevel: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary</SelectItem>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="very_high">Very High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div>
                <Label>Allergies (comma-separated)</Label>
                <Textarea
                  value={formData.allergies}
                  onChange={(e) => setFormData(prev => ({ ...prev, allergies: e.target.value }))}
                  placeholder="e.g., peanuts, shellfish, dairy"
                  className="h-20"
                />
              </div>

              <div>
                <Label>Food Dislikes (comma-separated)</Label>
                <Textarea
                  value={formData.dislikes}
                  onChange={(e) => setFormData(prev => ({ ...prev, dislikes: e.target.value }))}
                  placeholder="e.g., mushrooms, Brussels sprouts, spicy food"
                  className="h-20"
                />
              </div>

              <div>
                <Label>Favorite Foods (comma-separated)</Label>
                <Textarea
                  value={formData.favorites}
                  onChange={(e) => setFormData(prev => ({ ...prev, favorites: e.target.value }))}
                  placeholder="e.g., pizza, pasta, chicken"
                  className="h-20"
                />
              </div>

              <div>
                <Label>Dietary Restrictions (comma-separated)</Label>
                <Textarea
                  value={formData.dietaryRestrictions}
                  onChange={(e) => setFormData(prev => ({ ...prev, dietaryRestrictions: e.target.value }))}
                  placeholder="e.g., vegetarian, gluten-free, kosher"
                  className="h-20"
                />
              </div>

              <div>
                <Label>Health Goals (comma-separated)</Label>
                <Textarea
                  value={formData.healthGoals}
                  onChange={(e) => setFormData(prev => ({ ...prev, healthGoals: e.target.value }))}
                  placeholder="e.g., weight loss, muscle gain, healthy growth"
                  className="h-20"
                />
              </div>

              <div>
                <Label>Medical Conditions (comma-separated)</Label>
                <Textarea
                  value={formData.medicalConditions}
                  onChange={(e) => setFormData(prev => ({ ...prev, medicalConditions: e.target.value }))}
                  placeholder="e.g., diabetes, hypertension"
                  className="h-20"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button onClick={handleAddMember} disabled={createMemberMutation.isPending}>
                  {createMemberMutation.isPending ? "Adding..." : "Add Member"}
                </Button>
                <Button variant="outline" onClick={() => setIsAddingMember(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {familyProfiles.map((familyProfile: FamilyProfile) => (
          <Card key={familyProfile.user.id} className="relative">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={familyProfile.user.profileImage || ""} />
                    <AvatarFallback>{familyProfile.user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">{familyProfile.user.name}</CardTitle>
                    <div className="text-sm text-slate-500">
                      {familyProfile.user.isMainAccount ? "Main Account" : "Family Member"}
                      {familyProfile.profile.age && ` • Age ${familyProfile.profile.age}`}
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => openEditDialog(familyProfile)}>
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-green-600" />
                <span className="text-sm">{familyProfile.profile.dailyCalorieGoal} cal/day</span>
                <Badge variant="outline" className="text-xs">
                  {familyProfile.profile.activityLevel.replace('_', ' ')}
                </Badge>
              </div>

              {familyProfile.profile.allergies.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                    <span className="text-sm font-medium text-red-700">Allergies</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {familyProfile.profile.allergies.map((allergy, index) => (
                      <Badge key={index} variant="destructive" className="text-xs">
                        {allergy}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {familyProfile.profile.dislikes.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Utensils className="h-4 w-4 text-orange-500" />
                    <span className="text-sm font-medium text-orange-700">Dislikes</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {familyProfile.profile.dislikes.slice(0, 3).map((dislike, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {dislike}
                      </Badge>
                    ))}
                    {familyProfile.profile.dislikes.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{familyProfile.profile.dislikes.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {familyProfile.profile.favorites.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Heart className="h-4 w-4 text-pink-500" />
                    <span className="text-sm font-medium text-pink-700">Favorites</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {familyProfile.profile.favorites.slice(0, 3).map((favorite, index) => (
                      <Badge key={index} variant="outline" className="text-xs border-pink-200 text-pink-700">
                        {favorite}
                      </Badge>
                    ))}
                    {familyProfile.profile.favorites.length > 3 && (
                      <Badge variant="outline" className="text-xs border-pink-200 text-pink-700">
                        +{familyProfile.profile.favorites.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {familyProfile.profile.dietaryRestrictions.length > 0 && (
                <div>
                  <span className="text-sm font-medium">Dietary: </span>
                  <span className="text-sm text-slate-600">
                    {familyProfile.profile.dietaryRestrictions.join(', ')}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!selectedProfile} onOpenChange={() => setSelectedProfile(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Profile - {selectedProfile?.user.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Age</Label>
                <Input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                />
              </div>
              <div>
                <Label>Daily Calorie Goal</Label>
                <Input
                  type="number"
                  value={formData.dailyCalorieGoal}
                  onChange={(e) => setFormData(prev => ({ ...prev, dailyCalorieGoal: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label>Activity Level</Label>
              <Select value={formData.activityLevel} onValueChange={(value) => setFormData(prev => ({ ...prev, activityLevel: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedentary">Sedentary</SelectItem>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="very_high">Very High</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div>
              <Label>Allergies (comma-separated)</Label>
              <Textarea
                value={formData.allergies}
                onChange={(e) => setFormData(prev => ({ ...prev, allergies: e.target.value }))}
                className="h-20"
              />
            </div>

            <div>
              <Label>Food Dislikes (comma-separated)</Label>
              <Textarea
                value={formData.dislikes}
                onChange={(e) => setFormData(prev => ({ ...prev, dislikes: e.target.value }))}
                className="h-20"
              />
            </div>

            <div>
              <Label>Favorite Foods (comma-separated)</Label>
              <Textarea
                value={formData.favorites}
                onChange={(e) => setFormData(prev => ({ ...prev, favorites: e.target.value }))}
                className="h-20"
              />
            </div>

            <div>
              <Label>Dietary Restrictions (comma-separated)</Label>
              <Textarea
                value={formData.dietaryRestrictions}
                onChange={(e) => setFormData(prev => ({ ...prev, dietaryRestrictions: e.target.value }))}
                className="h-20"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button onClick={handleUpdateProfile} disabled={updateProfileMutation.isPending}>
                {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
              </Button>
              <Button variant="outline" onClick={() => setSelectedProfile(null)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}