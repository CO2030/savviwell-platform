import React, { useState, useRef, useEffect, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import { useTextToSpeech } from "@/hooks/use-text-to-speech";
import { apiRequest } from "@/lib/queryClient";
import { 
  Mic, 
  MicOff, 
  Send, 
  User, 
  Bot, 
  Download, 
  ShoppingCart, 
  Calendar,
  Loader2,
  Volume2,
  VolumeX
} from "lucide-react";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  metadata?: any;
  createdAt: string;
}

interface User {
  id: number;
  name: string;
  email: string;
  profileImage?: string;
  username: string;
  membershipType: string;
  isMainAccount: boolean;
  parentUserId: number | null;
  createdAt: string;
}

interface VoiceChatProps {
  conversationId?: number;
}

export function VoiceChat({ conversationId = 1 }: VoiceChatProps) {
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();

  const { isListening, startListening, stopListening, isSupported: speechSupported } = useSpeechRecognition();
  const { speak, isSpeaking } = useTextToSpeech();

  // Get messages for conversation
  const { data: messages = [], isLoading, error } = useQuery<Message[]>({
    queryKey: [`/api/conversations/${conversationId}/messages`],
    enabled: !!conversationId,
    refetchInterval: false,
    staleTime: 0,
  });

  // Log messages for debugging
  console.log("Current messages:", messages);
  console.log("Conversation ID:", conversationId);
  console.log("Messages loading:", isLoading);
  if (error) console.error("Messages error:", error);

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  // Save meal plan mutation with enhanced functionality
  const saveMealPlanMutation = useMutation({
    mutationFn: async (mealPlan: any) => {
      const response = await apiRequest("POST", "/api/meal-plans", {
        title: mealPlan.title || "Weekly Meal Plan",
        description: `AI-generated meal plan created on ${new Date().toDateString()}`,
        meals: mealPlan.meals,
        startDate: new Date(),
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        totalCalories: mealPlan.meals.reduce((total: number, day: any) => {
          return total + (day.breakfast?.calories || 0) + (day.lunch?.calories || 0) + (day.dinner?.calories || 0);
        }, 0),
        isActive: true,
        groceryList: generateGroceryListFromMeals(mealPlan.meals),
        preferences: {
          swapSuggestions: generateSwapSuggestions(mealPlan.meals),
          dietaryCompatible: checkDietaryCompatibility(mealPlan.meals)
        }
      });
      return response.json();
    },
    onSuccess: () => {
      console.log("Meal plan saved successfully");
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
    },
    onError: (error) => {
      console.error("Failed to save meal plan:", error);
    },
  });

  // Helper function to generate grocery list from meals
  const generateGroceryListFromMeals = (meals: any[]) => {
    const allIngredients = meals.flatMap(day => [
      ...(day.breakfast?.ingredients || []),
      ...(day.lunch?.ingredients || []),
      ...(day.dinner?.ingredients || [])
    ]);
    return Array.from(new Set(allIngredients)).sort();
  };

  // Helper function to generate swap suggestions
  const generateSwapSuggestions = (meals: any[]) => {
    const swaps: any[] = [];
    meals.forEach(day => {
      if (day.breakfast?.name.includes('salmon')) {
        swaps.push({ original: day.breakfast.name, swap: day.breakfast.name.replace('salmon', 'chicken'), type: 'protein' });
      }
      if (day.lunch?.name.includes('quinoa')) {
        swaps.push({ original: day.lunch.name, swap: day.lunch.name.replace('quinoa', 'brown rice'), type: 'grain' });
      }
    });
    return swaps;
  };

  // Helper function to check dietary compatibility
  const checkDietaryCompatibility = (meals: any[]) => {
    // This would check against user's dietary restrictions
    return {
      dairyFree: true, // Based on user profile
      glutenFree: false,
      vegetarian: false
    };
  };

  const handleSaveMealPlan = useCallback((mealPlan: any) => {
    saveMealPlanMutation.mutate(mealPlan);
  }, [saveMealPlanMutation]);

  // Save individual meal suggestions
  const saveMealSuggestionsMutation = useMutation({
    mutationFn: async (meals: any[]) => {
      const today = new Date();
      const promises = meals.map((meal, index) => {
        const mealDate = new Date(today);
        mealDate.setDate(today.getDate() + index);
        
        return apiRequest("POST", "/api/meals", {
          name: meal.name,
          calories: meal.calories || 450,
          ingredients: meal.ingredients || [`Ingredients for ${meal.name}`],
          instructions: meal.instructions || [`Prepare ${meal.name}`, "Follow recipe instructions"],
          mealType: 'dinner', // Default to dinner
          date: mealDate.toISOString().split('T')[0],
          isUserCreated: false
        });
      });
      
      return Promise.all(promises);
    },
    onSuccess: () => {
      console.log("Meal suggestions saved successfully");
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
    },
    onError: (error) => {
      console.error("Failed to save meal suggestions:", error);
    },
  });

  const handleSaveMealSuggestions = useCallback((meals: any[]) => {
    saveMealSuggestionsMutation.mutate(meals);
  }, [saveMealSuggestionsMutation]);

  const handleGenerateGroceryList = useCallback((meals: any[]) => {
    // Generate a basic grocery list from meal names
    const groceryItems = meals.flatMap(meal => {
      // Basic ingredient mapping based on meal names
      const ingredients = [];
      const mealName = meal.name.toLowerCase();
      
      if (mealName.includes('salmon')) ingredients.push('salmon fillet', 'lemon', 'olive oil');
      if (mealName.includes('chicken')) ingredients.push('chicken breast', 'garlic', 'herbs');
      if (mealName.includes('quinoa')) ingredients.push('quinoa', 'vegetable broth');
      if (mealName.includes('broccoli')) ingredients.push('fresh broccoli');
      if (mealName.includes('sweet potato')) ingredients.push('sweet potatoes', 'greek yogurt');
      if (mealName.includes('stir-fry')) ingredients.push('bell peppers', 'soy sauce', 'ginger');
      
      return ingredients;
    });
    
    const uniqueItems = Array.from(new Set(groceryItems));
    
    // Create a simple alert with the grocery list (could be enhanced with a modal)
    alert(`Grocery List:\n\n${uniqueItems.map(item => `• ${item}`).join('\n')}`);
  }, []);

  // Save wellness tips mutation
  const saveWellnessTipsMutation = useMutation({
    mutationFn: async (wellnessTips: any[]) => {
      // This would save to a wellness tips collection in the database
      const promises = wellnessTips.map(tip => {
        return apiRequest("POST", "/api/wellness-tips", {
          title: tip.title,
          content: tip.content,
          category: tip.category,
          tags: tip.tags || [],
          userId: 1, // Current user ID
          isUserCreated: false,
          aiGenerated: true
        });
      });
      
      return Promise.all(promises);
    },
    onSuccess: () => {
      console.log("Wellness tips saved successfully");
      // Could invalidate queries for wellness tips here
    },
    onError: (error) => {
      console.error("Failed to save wellness tips:", error);
    },
  });

  const handleSaveWellnessTips = useCallback((tips: any[]) => {
    saveWellnessTipsMutation.mutate(tips);
  }, [saveWellnessTipsMutation]);

  const handleSaveToWellnessJournal = useCallback((content: string) => {
    // Save to a personal wellness journal
    const journalEntry = {
      title: `Health Advice - ${new Date().toLocaleDateString()}`,
      content: content,
      category: 'ai_recommendations',
      tags: ['health', 'daily_routine', 'ai_advice'],
      date: new Date().toISOString().split('T')[0]
    };
    
    saveWellnessTipsMutation.mutate([journalEntry]);
  }, [saveWellnessTipsMutation]);

  // Helper function to determine health category
  const determineHealthCategory = (text: string) => {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('exercise') || lowerText.includes('workout') || lowerText.includes('fitness')) {
      return 'exercise';
    }
    if (lowerText.includes('sleep') || lowerText.includes('rest')) {
      return 'sleep';
    }
    if (lowerText.includes('nutrition') || lowerText.includes('eating') || lowerText.includes('food')) {
      return 'nutrition';
    }
    if (lowerText.includes('hydration') || lowerText.includes('water')) {
      return 'hydration';
    }
    if (lowerText.includes('meditation') || lowerText.includes('mindfulness') || lowerText.includes('stress')) {
      return 'mental_health';
    }
    
    return 'general_wellness';
  };

  // Helper function to extract health tags
  const extractHealthTags = (text: string) => {
    const tags = [];
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('morning')) tags.push('morning_routine');
    if (lowerText.includes('daily')) tags.push('daily_habit');
    if (lowerText.includes('balance')) tags.push('life_balance');
    if (lowerText.includes('energy')) tags.push('energy_boost');
    if (lowerText.includes('healthy')) tags.push('healthy_living');
    if (lowerText.includes('routine')) tags.push('routine');
    if (lowerText.includes('wellness')) tags.push('wellness');
    if (lowerText.includes('prevention')) tags.push('prevention');
    
    return tags.length > 0 ? tags : ['health_tip'];
  };

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      console.log("API request for message:", content);
      const response = await apiRequest("POST", `/api/conversations/${conversationId}/messages`, {
        content,
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("API response:", data);
      return data;
    },
    onMutate: () => {
      console.log("Starting message send...");
      setIsTyping(true);
    },
    onSuccess: (data) => {
      console.log("Message sent successfully:", data);
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}/messages`] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });

      // Speak AI response with cleaned content only if not muted
      if (data.assistantMessage?.content && !isMuted) {
        // Clean up the content for better speech
        const cleanedContent = data.assistantMessage.content
          .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold markdown
          .replace(/```json[\s\S]*?```/g, '') // Remove JSON blocks
          .replace(/\n+/g, ' ') // Replace line breaks with spaces
          .replace(/\s+/g, ' ') // Normalize whitespace
          .trim();

        if (cleanedContent) {
          // Use Callirrhoe voice with health-focused assistant personality
          speak(cleanedContent, { 
            voice: 'Callirrhoe',
            style: 'Say this as a warm, knowledgeable health and nutrition assistant. Speak with confidence and care, as if you are a trusted friend helping with meal planning and wellness.' 
          });
        }
      }
      setIsTyping(false);
    },
    onError: (error) => {
      console.error("Failed to send message:", error);
      setIsTyping(false);
    },
  });

  const handleSendMessage = () => {
    if (!input.trim() || sendMessageMutation.isPending) return;

    const message = input.trim();
    setInput("");
    
    // Immediately show the user message optimistically
    console.log("Sending message:", message);
    sendMessageMutation.mutate(message);
  };

  const handleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening((transcript) => {
        setInput(transcript);
        // Auto-send voice messages
        setTimeout(() => {
          if (transcript.trim()) {
            sendMessageMutation.mutate(transcript);
          }
        }, 500);
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 128)}px`;
    }
  }, [input]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      const container = messagesEndRef.current.parentElement;
      if (container) {
        // Ensure we can scroll to the very bottom
        container.scrollTop = container.scrollHeight;
      }
    }
  }, [messages, isTyping]);

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString([], { 
      hour: "2-digit", 
      minute: "2-digit" 
    });
  };

  const renderMessageContent = (message: Message) => {
    const content = message.content;

    // Check if message contains meal plan
    if (message.metadata?.type === "meal_plan") {
      const mealPlan = message.metadata.data;
      return (
        <div>
          <p className="text-slate-800 mb-4">{content.split("```")[0]}</p>

          {mealPlan?.meals && (
            <div className="mb-4">
              <Card className="border border-slate-200">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-slate-800">7-Day Meal Plan Created</h4>
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                      {mealPlan.meals.length} days
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">
                    Meal plan ready for review - click "View in Calendar" to see all meals and make adjustments.
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <Button 
              size="sm" 
              className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
              onClick={() => handleSaveMealPlan(mealPlan)}
            >
              <Download className="mr-2 h-4 w-4" />
              Save Plan
            </Button>
            <Button size="sm" className="bg-blue-100 text-blue-700 hover:bg-blue-200">
              <ShoppingCart className="mr-2 h-4 w-4" />
              Shopping List
            </Button>
            <Button 
              size="sm" 
              className="bg-violet-100 text-violet-700 hover:bg-violet-200"
              onClick={() => window.location.href = '/meal-planning'}
            >
              <Calendar className="mr-2 h-4 w-4" />
              View in Calendar
            </Button>
          </div>
        </div>
      );
    }

    // Check if message contains meal suggestions (look for numbered lists or meal names)
    const hasMealSuggestions = message.role === "assistant" && (
      content.includes("meal") || 
      content.includes("recipe") ||
      content.includes("building") ||
      /\d+\.\s*\*\*/.test(content) // Numbered list with bold text
    );

    if (hasMealSuggestions) {
      // Extract meal suggestions from the content
      const mealMatches = content.match(/\d+\.\s*\*\*(.*?)\*\*/g) || [];
      const extractedMeals = mealMatches.map(match => {
        const mealName = match.replace(/\d+\.\s*\*\*(.*?)\*\*.*/, '$1');
        return {
          name: mealName,
          calories: 450, // Default estimate
          description: match
        };
      });

      return (
        <div>
          <p className="text-slate-800 mb-4">{content}</p>

          {extractedMeals.length > 0 && (
            <div className="mb-4">
              <Card className="border border-slate-200">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-slate-800">Meal Suggestions</h4>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                      {extractedMeals.length} meals
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">
                    Save these meal suggestions to your calendar for easy planning.
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <Button 
              size="sm" 
              className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
              onClick={() => handleSaveMealSuggestions(extractedMeals)}
            >
              <Download className="mr-2 h-4 w-4" />
              Save Meals
            </Button>
            <Button 
              size="sm" 
              className="bg-blue-100 text-blue-700 hover:bg-blue-200"
              onClick={() => handleGenerateGroceryList(extractedMeals)}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Shopping List
            </Button>
            <Button 
              size="sm" 
              className="bg-violet-100 text-violet-700 hover:bg-violet-200"
              onClick={() => window.location.href = '/meal-planning'}
            >
              <Calendar className="mr-2 h-4 w-4" />
              View Calendar
            </Button>
          </div>
        </div>
      );
    }

    // Check if message contains health/wellness related content
    const isHealthRelated = message.role === "assistant" && (
      content.includes("health") || 
      content.includes("wellness") ||
      content.includes("exercise") ||
      content.includes("sleep") ||
      content.includes("hydration") ||
      content.includes("meditation") ||
      content.includes("routine") ||
      content.includes("fitness") ||
      content.includes("nutrition") ||
      content.includes("mindfulness") ||
      content.includes("tips") ||
      content.includes("daily") || 
      content.includes("healthy") || 
      content.includes("balance") ||
      content.includes("protein") ||
      content.includes("water") ||
      content.includes("active") ||
      content.includes("mindful") ||
      /\d+\.\s*\*\*.*?\*\*/.test(content) // Numbered list with bold text
    );

    if (isHealthRelated) {
      // Extract health tips from the content
      const healthTips: any[] = [];
      const tipMatches = content.match(/\d+\.\s*\*\*(.*?)\*\*:?\s*(.*?)(?=\d+\.\s*\*\*|$)/g) || [];
      
      if (tipMatches.length > 0) {
        tipMatches.forEach(match => {
          const lines = match.split('\n').filter(line => line.trim());
          if (lines.length > 0) {
            const titleMatch = lines[0].match(/\d+\.\s*\*\*(.*?)\*\*/);
            const title = titleMatch ? titleMatch[1] : lines[0].replace(/\d+\.\s*/, '');
            const tipContent = lines.slice(1).join(' ').trim() || lines[0];
            
            healthTips.push({
              title: title,
              content: tipContent,
              category: determineHealthCategory(title + ' ' + tipContent),
              tags: extractHealthTags(title + ' ' + tipContent)
            });
          }
        });
      } else {
        // If no numbered tips found, create a general health tip
        healthTips.push({
          title: "Daily Health Advice",
          content: content,
          category: determineHealthCategory(content),
          tags: extractHealthTags(content)
        });
      }

      return (
        <div>
          <p className="text-slate-800 mb-4">{content}</p>

          <div className="mb-4">
            <Card className="border border-emerald-200 bg-emerald-50">
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-emerald-800">Health & Wellness Tips</h4>
                  <Badge variant="secondary" className="bg-emerald-200 text-emerald-800">
                    Save for later
                  </Badge>
                </div>
                <p className="text-sm text-emerald-700">
                  Save these health recommendations to your wellness library for easy reference.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button 
              size="sm" 
              className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
              onClick={() => handleSaveWellnessTips(healthTips)}
            >
              <Download className="mr-2 h-4 w-4" />
              Save Tips
            </Button>
            <Button 
              size="sm" 
              className="bg-blue-100 text-blue-700 hover:bg-blue-200"
              onClick={() => handleSaveToWellnessJournal(content)}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Save to Journal
            </Button>
            <Button 
              size="sm" 
              className="bg-violet-100 text-violet-700 hover:bg-violet-200"
              onClick={() => window.location.href = '/wellness-library'}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              View Library
            </Button>
          </div>
        </div>
      );
    }

    return <p className="text-slate-800">{content}</p>;
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-4 chat-scroll" style={{ maxHeight: 'calc(100vh - 200px)' }}>
        {/* Welcome message */}
        {messages.length === 0 && (
          <div className="flex items-start space-x-3">
            <Avatar className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-500">
              <AvatarFallback>
                <Bot className="h-4 w-4 text-white" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Card className="bg-white border border-slate-200 shadow-sm">
                <CardContent className="p-4">
                  <p className="text-slate-800">
                    Hello {user?.name}! I'm your AI health assistant. I can help you plan meals, 
                    track nutrition, book restaurants, and provide personalized health recommendations. 
                    You can type your questions or use voice - I respond to both! How can I assist you today?
                  </p>
                </CardContent>
              </Card>
              <p className="text-xs text-slate-500 mt-1">Just now</p>
            </div>
          </div>
        )}

        {/* Messages */}
        {messages.map((message: Message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-3 ${
              message.role === "user" ? "justify-end" : ""
            }`}
          >
            {message.role === "assistant" && (
              <Avatar className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-500 flex-shrink-0">
                <AvatarFallback>
                  <Bot className="h-4 w-4 text-white" />
                </AvatarFallback>
              </Avatar>
            )}

            <div className={`flex-1 ${message.role === "user" ? "max-w-lg" : ""}`}>
              <Card
                className={`shadow-sm ${
                  message.role === "user"
                    ? "bg-blue-500 text-white border-blue-500"
                    : "bg-white border-slate-200"
                }`}
              >
                <CardContent className="p-4">
                  {message.role === "assistant" ? (
                    renderMessageContent(message)
                  ) : (
                    <p className="text-white">{message.content}</p>
                  )}
                </CardContent>
              </Card>
              <p
                className={`text-xs text-slate-500 mt-1 ${
                  message.role === "user" ? "text-right" : ""
                }`}
              >
                {formatTime(message.createdAt)}
              </p>
            </div>

            {message.role === "user" && (
              <Avatar className="w-8 h-8 flex-shrink-0">
                <AvatarImage src={user?.profileImage} alt={user?.name} />
                <AvatarFallback>
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
            )}
          </div>
        ))}

        {/* Typing indicator */}
        {(isTyping || sendMessageMutation.isPending) && (
          <div className="flex items-start space-x-3">
            <Avatar className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-500">
              <AvatarFallback>
                <Bot className="h-4 w-4 text-white" />
              </AvatarFallback>
            </Avatar>
            <Card className="bg-white border border-slate-200 shadow-sm">
              <CardContent className="p-4">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-slate-200 p-4 lg:p-6 bg-white">
        <div className="flex items-end space-x-3">
          {/* Voice Button */}
          <Button
            onClick={handleVoiceInput}
            disabled={!speechSupported}
            className={`relative w-12 h-12 rounded-full shadow-lg transition-all duration-200 ${
              isListening
                ? "bg-red-500 hover:bg-red-600"
                : "bg-gradient-to-br from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600"
            }`}
          >
            {isListening ? (
              <MicOff className="h-5 w-5 text-white" />
            ) : (
              <Mic className="h-5 w-5 text-white" />
            )}

            {/* Recording pulse animation */}
            {isListening && (
              <div className="absolute -inset-4 border-2 border-red-500 rounded-full animate-ping opacity-75" />
            )}
          </Button>

          {/* Mute Toggle Button */}
          <Button
            onClick={() => {
              setIsMuted(!isMuted);
              if (isSpeaking) {
                // Stop current speech when muting
                window.speechSynthesis.cancel();
              }
            }}
            className={`w-12 h-12 rounded-full shadow-lg transition-all duration-200 ${
              isMuted
                ? "bg-gray-500 hover:bg-gray-600"
                : "bg-emerald-500 hover:bg-emerald-600"
            }`}
            title={isMuted ? "Unmute AI responses" : "Mute AI responses"}
          >
            {isMuted ? (
              <VolumeX className="h-5 w-5 text-white" />
            ) : (
              <Volume2 className="h-5 w-5 text-white" />
            )}
          </Button>

          {/* Text Input */}
          <div className="flex-1 flex items-end space-x-2">
            <div className={`flex-1 min-h-[3rem] max-h-32 rounded-2xl px-4 py-3 transition-all ${
              sendMessageMutation.isPending 
                ? 'bg-slate-200 ring-2 ring-blue-300' 
                : 'bg-slate-100 focus-within:bg-white focus-within:ring-2 focus-within:ring-blue-500'
            }`}>
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={sendMessageMutation.isPending ? "Sending message..." : "Type your message here... or use the microphone button"}
                disabled={sendMessageMutation.isPending}
                className="w-full bg-transparent resize-none border-none outline-none text-slate-800 placeholder-slate-500 min-h-0 disabled:opacity-50"
                rows={1}
              />
            </div>

            {/* Send Button */}
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim() || sendMessageMutation.isPending}
              size="icon"
              className="w-10 h-10 rounded-full"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Status indicators */}
        {isListening && (
          <div className="mt-2 flex items-center justify-center space-x-2 text-sm text-slate-500">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span>Listening...</span>
          </div>
        )}
        
        {isMuted && !isListening && (
          <div className="mt-2 flex items-center justify-center space-x-2 text-xs text-slate-400">
            <VolumeX className="h-3 w-3" />
            <span>AI voice responses are muted</span>
          </div>
        )}
        
        {!isListening && !isMuted && input.length === 0 && (
          <div className="mt-2 flex items-center justify-center text-xs text-slate-400">
            <span>Type your message or press the mic button • Press Enter to send</span>
          </div>
        )}
      </div>
    </div>
  );
}