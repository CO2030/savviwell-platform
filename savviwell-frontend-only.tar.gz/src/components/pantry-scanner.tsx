import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Upload, Package, Calendar, AlertTriangle, Plus, Edit, Trash2, Scan, Sparkles, MoreVertical, Archive, Share, Settings } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PantryItem {
  id: number;
  itemName: string;
  category: string;
  quantity: number;
  unit: string;
  expirationDate: string | null;
  location: string;
  addedDate: string;
  notes: string | null;
}

interface ScanResult {
  type: "ingredients" | "meal";
  items: {
    name: string;
    category: string;
    confidence: number;
  }[];
  meal?: {
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    ingredients: string[];
    benefits: string[];
  };
  suggestions: string[];
}

export function PantryScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [selectedItems, setSelectedItems] = useState<Set<number>>(new Set());
  const [isAddingManual, setIsAddingManual] = useState(false);
  const [editingItem, setEditingItem] = useState<PantryItem | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [scanType, setScanType] = useState<'pantry' | 'plate'>('pantry');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    itemName: "",
    category: "vegetables",
    quantity: "1",
    unit: "pieces",
    expirationDate: "",
    location: "pantry",
    notes: ""
  });

  const { data: pantryItems = [], isLoading } = useQuery<PantryItem[]>({
    queryKey: ["/api/pantry"],
  });

  const { data: expiringItems = [] } = useQuery<PantryItem[]>({
    queryKey: ["/api/pantry/expiring"],
  });

  const addItemMutation = useMutation({
    mutationFn: async (itemData: any) => {
      return apiRequest("POST", "/api/pantry", itemData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pantry"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pantry/expiring"] });
      toast({
        title: "Item added",
        description: "Pantry item has been successfully added.",
      });
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      return apiRequest("PATCH", `/api/pantry/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pantry"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pantry/expiring"] });
      setEditingItem(null);
      toast({
        title: "Item updated",
        description: "Pantry item has been successfully updated.",
      });
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/pantry/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pantry"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pantry/expiring"] });
      toast({
        title: "Item deleted",
        description: "Pantry item has been successfully removed.",
      });
    },
  });

  const scanMutation = useMutation({
    mutationFn: async (imageData: string) => {
      console.log('🔍 Starting scan request...');
      console.log('📊 Image data size:', imageData.length);
      console.log('📋 Scan type:', scanType);
      
      const response = await apiRequest("POST", "/api/pantry/scan", { 
        image: imageData, 
        scanType: scanType 
      });
      
      console.log('📡 Response status:', response.status);
      console.log('📡 Response headers:', response.headers);
      
      const result = await response.json();
      console.log('📋 Server response:', result);

      if (!result.success) {
        console.error('❌ Scan failed:', result.message);
        throw new Error(result.message || 'Scan failed');
      }

      console.log('✅ Scan successful:', result);
      return result;
    },
    onSuccess: (result: ScanResult) => {
      setScanResult(result);
      setIsScanning(false);
      stopCamera();
      toast({
        title: "Scan Complete",
        description: `Found ${result.items?.length || 0} items`,
      });
    },
    onError: (error: any) => {
      const errorMessage = error.message || "Unable to analyze the image. Please try again.";
      toast({
        title: "Scan Failed",
        description: errorMessage,
        variant: "destructive",
      });
      setIsScanning(false);
    },
  });

  const logMealMutation = useMutation({
    mutationFn: async (mealData: {
      mealName: string;
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
      fiber: number;
      notes: string;
    }) => {
      const response = await apiRequest("POST", "/api/nutrition/log-meal", mealData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Meal Logged",
        description: "Your meal has been added to today's nutrition log.",
      });
      setScanResult(null);
      queryClient.invalidateQueries({ queryKey: ["/api/nutrition/today"] });
    },
    onError: () => {
      toast({
        title: "Logging Failed",
        description: "Failed to log your meal. Please try again.",
        variant: "destructive",
      });
    },
  });

  const startCamera = async () => {
    console.log(`🎥 Starting camera for ${scanType} scanning...`);

    try {
      // Check if camera is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast({
          title: "Camera Not Available",
          description: "Your browser doesn't support camera access. Please use 'Upload Photo' instead.",
          variant: "destructive"
        });
        return;
      }

      // Request camera permission with fallback options
      let stream: MediaStream;
      try {
        // Try back camera first (better for food scanning)
        console.log("🔄 Attempting to access back camera...");
        stream = await navigator.mediaDevices.getUserMedia({
          video: { 
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: 'environment'
          }
        });
        console.log("✅ Back camera access successful");
      } catch (backCameraError) {
        try {
          // Fallback to any available camera
          console.log("🔄 Falling back to any available camera...");
          stream = await navigator.mediaDevices.getUserMedia({
            video: { 
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }
          });
          console.log("✅ Front camera access successful");
        } catch (anyCameraError) {
          // Fallback to basic video constraints
          console.log("🔄 Falling back to basic video constraints...");
          stream = await navigator.mediaDevices.getUserMedia({
            video: true
          });
          console.log("✅ Basic camera access successful");
        }
      }

      setCameraStream(stream);
      setIsScanning(true);

      if (videoRef.current) {
        const video = videoRef.current;

        // Clear any existing stream
        if (video.srcObject) {
          const tracks = (video.srcObject as MediaStream).getTracks();
          tracks.forEach(track => track.stop());
        }

        video.srcObject = stream;
        
        // Force immediate play attempt
        video.load(); // Refresh the video element
        
        // Set video attributes for autoplay
        video.muted = true;
        video.playsInline = true;
        video.autoplay = true;
        
        console.log('🔗 Stream attached to video element');
        console.log('📊 Stream details:', {
          active: stream.active,
          id: stream.id,
          tracks: stream.getTracks().length
        });

        // Wait for metadata to load before playing
        video.addEventListener('loadedmetadata', () => {
          console.log('📹 Video metadata loaded, attempting to play...');
          console.log('📹 Video dimensions:', video.videoWidth, 'x', video.videoHeight);
          
          const playPromise = video.play();
          if (playPromise) {
            playPromise.then(() => {
              console.log('✅ Video playing successfully');
              video.style.backgroundColor = 'transparent';
            }).catch((error) => {
              console.log('⚠️ Autoplay failed:', error);
              video.style.backgroundColor = '#1f2937';
              toast({
                title: "Click to start camera",
                description: "Click on the camera preview to start the video feed."
              });
            });
          }
        });

        // Force a play attempt immediately as well
        setTimeout(() => {
          if (video.paused) {
            console.log('🔄 Forcing video play after timeout...');
            video.play().catch(console.error);
          }
        }, 100);

        // Add click handler for manual play
        video.onclick = () => {
          console.log('👆 Video clicked, attempting play...');
          if (video.paused) {
            video.play().then(() => {
              console.log('✅ Video playing after click');
            }).catch(console.error);
          }
        };

        // Enhanced video loading detection with debugging
        video.onloadedmetadata = () => {
          const debugInfo = {
            width: video.videoWidth,
            height: video.videoHeight,
            readyState: video.readyState,
            srcObject: !!video.srcObject,
            streamActive: stream.active,
            tracks: stream.getTracks().map(t => ({ kind: t.kind, enabled: t.enabled, readyState: t.readyState })),
            videoDisplayStyle: window.getComputedStyle(video).display,
            videoVisibility: window.getComputedStyle(video).visibility,
            videoOpacity: window.getComputedStyle(video).opacity
          };
          console.log('📹 Video metadata loaded:', debugInfo);
          
          // Force video dimensions if they're not set
          if (video.videoWidth > 0 && video.videoHeight > 0) {
            video.style.width = 'auto';
            video.style.height = 'auto';
            video.style.maxWidth = '100%';
            console.log('📹 Video dimensions applied');
          }
        };

        video.oncanplay = () => {
          console.log('▶️ Video ready to play');
          console.log('📊 Video element details:', {
            videoWidth: video.videoWidth,
            videoHeight: video.videoHeight,
            currentTime: video.currentTime,
            paused: video.paused,
            muted: video.muted,
            autoplay: video.autoplay
          });
        };

        video.onplay = () => {
          console.log('🎬 Video started playing');
        };

        video.onerror = (e) => {
          console.error('❌ Video error:', e);
        };

        video.onloadstart = () => {
          console.log('🔄 Video load started');
        };

        // Force video to play and show stream
        const attemptPlay = async () => {
          try {
            // Ensure video is properly configured
            video.muted = true;
            video.autoplay = true;
            video.playsInline = true;
            
            console.log('🎯 Attempting video play...');
            await video.play();
            console.log('✅ Video playback successful');
            
            // Double-check that the video is actually displaying the stream
            setTimeout(() => {
              if (video.videoWidth > 0 && video.videoHeight > 0) {
                console.log('✅ Video stream confirmed working');
                toast({
                  title: "Camera Active",
                  description: `Ready to scan ${scanType === 'pantry' ? 'pantry items' : 'meals'}! Point camera at food and click 'Capture & Analyze'`
                });
              } else {
                console.warn('⚠️ Video element has no dimensions');
                toast({
                  title: "Camera Issue",
                  description: "Camera started but no video feed detected. Try refreshing or using a different browser.",
                  variant: "destructive"
                });
              }
            }, 1000);
            
          } catch (playError: any) {
            console.error('❌ Video play failed:', playError);
            
            // Add click-to-play fallback
            const clickHandler = () => {
              video.play().then(() => {
                console.log('✅ Video started after click');
                toast({
                  title: "Camera Active",
                  description: "Camera is now active!"
                });
              }).catch(console.error);
            };
            
            video.addEventListener('click', clickHandler, { once: true });

            toast({
              title: "Camera Ready",
              description: "Click on the video preview to start camera",
            });
          }
        };

        // Force immediate auto-activation
        const forceAutoPlay = async () => {
          try {
            // Wait a brief moment for stream attachment
            await new Promise(resolve => setTimeout(resolve, 100));
            
            // Set all required attributes for autoplay
            video.muted = true;
            video.autoplay = true;
            video.playsInline = true;
            video.setAttribute('webkit-playsinline', 'true');
            
            // Force play immediately
            await video.play();
            console.log('✅ Auto-activation successful');
            
            // Verify stream is working after a moment
            setTimeout(() => {
              if (video.videoWidth > 0 && video.videoHeight > 0) {
                console.log('✅ Video stream auto-activated and working');
                toast({
                  title: "Camera Active",
                  description: "Ready to scan! Point at your food and click Capture."
                });
              } else {
                console.warn('⚠️ Auto-activation attempted but no feed detected');
              }
            }, 500);
            
          } catch (error) {
            console.log('⚠️ Auto-activation failed, but camera stream is ready');
            // Don't show error - this is expected in many browsers
          }
        };

        // Try immediate auto-activation
        forceAutoPlay();
        
        // Also try again when metadata loads (backup)
        video.addEventListener('loadedmetadata', forceAutoPlay, { once: true });
      }
    } catch (error: any) {
      console.error("❌ Error accessing camera:", error);

      let errorMessage = "Failed to access camera. ";
      if (error.name === 'NotAllowedError') {
        errorMessage += "Please allow camera permissions in your browser and refresh the page.";
      } else if (error.name === 'NotFoundError') {
        errorMessage += "No camera found. Please use 'Upload Photo' instead.";
      } else if (error.name === 'NotReadableError') {
        errorMessage += "Camera is being used by another app. Please close other apps and try again.";
      } else {
        errorMessage += "Please try 'Upload Photo' instead.";
      }

      toast({
        title: "Camera Error",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsScanning(false);
  };

  const captureImage = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas) {
      toast({
        title: "Camera Error",
        description: "Camera is not ready. Please start the camera first.",
        variant: "destructive"
      });
      return;
    }

    // Wait for video to be fully loaded
    if (video.readyState < 2) {
      toast({
        title: "Video Loading",
        description: "Please wait for video to load completely.",
        variant: "destructive"
      });
      return;
    }

    if (video.videoWidth === 0 || video.videoHeight === 0) {
      toast({
        title: "Camera Error",
        description: "No video feed detected. Please ensure camera permissions are granted.",
        variant: "destructive"
      });
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      toast({
        title: "Canvas Error",
        description: "Canvas context not available. Please try refreshing the page.",
        variant: "destructive"
      });
      return;
    }

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw the current video frame
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Convert to base64
    try {
      const imageData = canvas.toDataURL('image/jpeg', 0.8);

      // Validate captured image
      if (imageData.length < 1000) {
        toast({
          title: "Image Error",
          description: "Captured image is too small. Please ensure camera is working properly.",
          variant: "destructive"
        });
        return;
      }

      // Test image validity
      const img = new Image();
      img.onload = () => {
        scanMutation.mutate(imageData);
      };
      img.onerror = () => {
        toast({
          title: "Image Error",
          description: "Captured image data is invalid. Please try again.",
          variant: "destructive"
        });
      };
      img.src = imageData;

    } catch (error) {
      console.error('Failed to convert canvas to data URL:', error);
      toast({
        title: "Capture Error",
        description: "Failed to capture image. Please try again.",
        variant: "destructive"
      });
    }
  };

  const runDemo = () => {
    const demoResult: ScanResult = {
      type: scanType === 'pantry' ? 'ingredients' : 'meal',
      items: scanType === 'pantry' ? [
        { name: "Tomatoes", category: "vegetables", confidence: 0.95 },
        { name: "Chicken Breast", category: "proteins", confidence: 0.92 },
        { name: "Spinach", category: "vegetables", confidence: 0.88 }
      ] : [
        { name: "Grilled Chicken Salad", category: "meal", confidence: 0.94 }
      ],
      meal: scanType === 'plate' ? {
        name: "Grilled Chicken Salad",
        calories: 320,
        protein: 28,
        carbs: 12,
        fat: 18,
        fiber: 4,
        ingredients: ["chicken breast", "mixed greens", "tomatoes", "olive oil"],
        benefits: ["High protein", "Rich in vitamins", "Heart healthy fats"]
      } : undefined,
      suggestions: scanType === 'pantry' ? 
        ["Perfect for making a fresh salad", "Try grilling the chicken with herbs"] :
        ["Great post-workout meal", "Consider adding avocado for healthy fats"]
    };
    setScanResult(demoResult);
    toast({
      title: "Demo Complete",
      description: `This shows how the ${scanType} scanner works with real food images.`
    });
  };

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        const maxWidth = 800;
        const maxHeight = 600;
        let { width, height } = img;

        if (width > height) {
          if (width > maxWidth) {
            height = (height * maxWidth) / width;
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = (width * maxHeight) / height;
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };

      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];

    if (!file) {
      console.error('No file selected');
      return;
    }

    // Check file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file (JPG, PNG, etc.)",
        variant: "destructive"
      });
      return;
    }

    // Check file size (limit to 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image under 10MB",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Processing uploaded file:', file.name, file.size, 'bytes');
      console.log('Scan type:', scanType);
      const compressedImage = await compressImage(file);
      console.log('Image compressed, new size:', compressedImage.length);
      scanMutation.mutate(compressedImage);
    } catch (error) {
      console.error('Upload processing error:', error);
      toast({
        title: "Upload Error",
        description: "Failed to process the image. Please try again.",
        variant: "destructive"
      });
    }

    // Clear the input so the same file can be selected again
    event.target.value = '';
  };

  const addItemFromScan = (scanItem: any) => {
    const processedData = {
      itemName: scanItem.name,
      category: scanItem.category,
      quantity: 1,
      unit: "pieces",
      location: "pantry"
    };
    addItemMutation.mutate(processedData);
  };

  const addSelectedItems = () => {
    if (!scanResult) return;

    scanResult.items.forEach((item, index) => {
      if (selectedItems.has(index)) {
        addItemFromScan(item);
      }
    });

    setSelectedItems(new Set());
    setScanResult(null);
  };

  const handleManualAdd = () => {
    const processedData = {
      ...formData,
      quantity: parseFloat(formData.quantity),
      expirationDate: formData.expirationDate || null
    };
    addItemMutation.mutate(processedData);
    setIsAddingManual(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!editingItem) return;

    const processedData = {
      ...formData,
      quantity: parseFloat(formData.quantity),
      expirationDate: formData.expirationDate || null
    };
    updateItemMutation.mutate({ id: editingItem.id, data: processedData });
  };

  const openEditDialog = (item: PantryItem) => {
    setEditingItem(item);
    setFormData({
      itemName: item.itemName,
      category: item.category,
      quantity: item.quantity.toString(),
      unit: item.unit,
      expirationDate: item.expirationDate ? item.expirationDate.split('T')[0] : "",
      location: item.location,
      notes: item.notes || ""
    });
  };

  const resetForm = () => {
    setFormData({
      itemName: "",
      category: "vegetables",
      quantity: "1",
      unit: "pieces", 
      expirationDate: "",
      location: "pantry",
      notes: ""
    });
  };

  const getDaysUntilExpiration = (expirationDate: string) => {
    const expDate = new Date(expirationDate);
    const today = new Date();
    const diffTime = expDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const getExpirationColor = (expirationDate: string | null) => {
    if (!expirationDate) return "text-slate-500";
    const days = getDaysUntilExpiration(expirationDate);
    if (days < 0) return "text-red-600";
    if (days <= 2) return "text-orange-600";
    if (days <= 7) return "text-yellow-600";
    return "text-green-600";
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "vegetables": return "🥕";
      case "proteins": return "🥩";
      case "grains": return "🌾";
      case "dairy": return "🥛";
      case "pantry": return "🥫";
      case "spices": return "🧂";
      default: return "📦";
    }
  };

  if (isLoading) {
    return <div className="p-6">Loading pantry...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Package className="h-6 w-6 text-green-600" />
          <h2 className="text-2xl font-semibold">Smart Pantry</h2>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Archive className="h-4 w-4 mr-2" />
                Export Pantry List
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Share className="h-4 w-4 mr-2" />
                Share Inventory
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Settings className="h-4 w-4 mr-2" />
                Pantry Settings
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <div className="flex gap-2">
          <Select value={scanType} onValueChange={(value: 'pantry' | 'plate') => setScanType(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pantry">📦 Pantry</SelectItem>
              <SelectItem value="plate">🍽️ Plate</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={startCamera} disabled={isScanning}>
            <Camera className="h-4 w-4 mr-2" />
            Scan {scanType === 'pantry' ? 'Items' : 'Meal'}
          </Button>
          <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-4 w-4 mr-2" />
            Upload Photo
          </Button>
          <Button variant="outline" onClick={runDemo} className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <Plus className="h-4 w-4 mr-2" />
            Try Demo
          </Button>
          <Dialog open={isAddingManual} onOpenChange={setIsAddingManual}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Manually
              </Button>
            </DialogTrigger>
          </Dialog>
          </div>
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Camera Scanner */}
      {isScanning && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scan className="h-5 w-5" />
              {scanType === 'pantry' ? '📦 Pantry Scanner' : '🍽️ Meal Scanner'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  controls={false}
                  className="w-full max-w-md mx-auto rounded-lg border-2 border-blue-300 bg-black cursor-pointer"
                  style={{ 
                    minHeight: '240px',
                    minWidth: '320px',
                    display: 'block'
                  }}
                  onClick={() => {
                    const video = videoRef.current;
                    console.log('👆 Video element clicked directly');
                    if (video) {
                      video.play().then(() => {
                        console.log('✅ Video playing after direct click');
                      }).catch((error) => {
                        console.error('❌ Video play failed:', error);
                      });
                    }
                  }}
                />
                <canvas ref={canvasRef} className="hidden" />
                <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-1 rounded text-xs pointer-events-none">
                  📹 Live Camera
                </div>
              </div>
              <div className="flex gap-2 justify-center">
                <Button onClick={captureImage} disabled={scanMutation.isPending}>
                  {scanMutation.isPending ? "Analyzing with AI..." : "📸 Capture & Analyze"}
                </Button>
                <Button 
                  variant="secondary" 
                  onClick={() => {
                    stopCamera();
                    fileInputRef.current?.click();
                  }}
                >
                  📁 Upload Photo
                </Button>
                <Button variant="outline" onClick={stopCamera}>
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Scan Results */}
      {scanResult && (
        <Card>
          <CardHeader>
            <CardTitle>
              {scanResult.type === "meal" ? "Meal Analysis" : "Scan Results"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {scanResult.type === "meal" && scanResult.meal ? (
                /* Meal Analysis Display */
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h3 className="font-semibold text-lg mb-3">{scanResult.meal.name}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                      <div className="text-center p-2 bg-white rounded border">
                        <div className="text-2xl font-bold text-orange-600">{scanResult.meal.calories}</div>
                        <div className="text-sm text-slate-600">Calories</div>
                      </div>
                      <div className="text-center p-2 bg-white rounded border">
                        <div className="text-2xl font-bold text-blue-600">{scanResult.meal.protein}g</div>
                        <div className="text-sm text-slate-600">Protein</div>
                      </div>
                      <div className="text-center p-2 bg-white rounded border">
                        <div className="text-2xl font-bold text-green-600">{scanResult.meal.carbs}g</div>
                        <div className="text-sm text-slate-600">Carbs</div>
                      </div>
                      <div className="text-center p-2 bg-white rounded border">
                        <div className="text-2xl font-bold text-purple-600">{scanResult.meal.fat}g</div>
                        <div className="text-sm text-slate-600">Fat</div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <h4 className="font-medium text-slate-700 mb-1">Key Ingredients:</h4>
                        <p className="text-sm text-slate-600">{scanResult.meal.ingredients.join(", ")}</p>
                      </div>

                      <div>
                        <h4 className="font-medium text-slate-700 mb-1">Health Benefits:</h4>
                        <ul className="text-sm text-slate-600 list-disc list-inside">
                          {scanResult.meal.benefits.map((benefit, index) => (
                            <li key={index}>{benefit}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={() => logMealMutation.mutate({
                        mealName: scanResult.meal!.name,
                        calories: scanResult.meal!.calories,
                        protein: scanResult.meal!.protein,
                        carbs: scanResult.meal!.carbs,
                        fat: scanResult.meal!.fat,
                        fiber: scanResult.meal!.fiber,
                        notes: `Ingredients: ${scanResult.meal!.ingredients.join(", ")}`
                      })}
                      disabled={logMealMutation.isPending}
                    >
                      {logMealMutation.isPending ? "Logging..." : "Log to Nutrition Journal"}
                    </Button>
                    <Button variant="outline" onClick={() => setScanResult(null)}>
                      Close
                    </Button>
                  </div>
                </div>
              ) : (
                /* Ingredient Scanning Display */
                <div className="space-y-4">
                  <div className="grid gap-2">
                    {scanResult.items.map((item, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                        <input
                          type="checkbox"
                          checked={selectedItems.has(index)}
                          onChange={(e) => {
                            const newSelected = new Set(selectedItems);
                            if (e.target.checked) {
                              newSelected.add(index);
                            } else {
                              newSelected.delete(index);
                            }
                            setSelectedItems(newSelected);
                          }}
                        />
                        <div className="flex-1">
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-slate-500">
                            {item.category} • {Math.round(item.confidence * 100)}% confidence
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={addSelectedItems} disabled={selectedItems.size === 0}>
                      Add Selected Items ({selectedItems.size})
                    </Button>
                    <Button variant="outline" onClick={() => setScanResult(null)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              {/* Suggestions */}
              {scanResult.suggestions.length > 0 && (
                <div className="mt-4 p-3 bg-slate-50 rounded-lg">
                  <h4 className="font-medium text-slate-700 mb-2">Suggestions:</h4>
                  <ul className="text-sm text-slate-600 space-y-1">
                    {scanResult.suggestions.map((suggestion, index) => (
                      <li key={index}>• {suggestion}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Expiring Items Alert */}
      {expiringItems.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-700">
              <AlertTriangle className="h-5 w-5" />
              Items Expiring Soon
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {expiringItems.map((item: PantryItem) => (
                <div key={item.id} className="flex items-center justify-between p-2 bg-white rounded">
                  <span>{getCategoryIcon(item.category)} {item.itemName}</span>
                  <span className={`text-sm ${getExpirationColor(item.expirationDate)}`}>
                    {item.expirationDate && getDaysUntilExpiration(item.expirationDate) < 0
                      ? "Expired"
                      : `${getDaysUntilExpiration(item.expirationDate!)} days`
                    }
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pantry Items Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {pantryItems.map((item: PantryItem) => (
          <Card key={item.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{getCategoryIcon(item.category)}</span>
                  <div>
                    <div className="font-medium">{item.itemName}</div>
                    <div className="text-sm text-slate-500">
                      {item.quantity} {item.unit} • {item.location}
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => openEditDialog(item)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => deleteItemMutation.mutate(item.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <Badge variant="outline" className="mb-2">
                {item.category}
              </Badge>

              {item.expirationDate && (
                <div className={`text-sm flex items-center gap-1 ${getExpirationColor(item.expirationDate)}`}>
                  <Calendar className="h-3 w-3" />
                  Expires: {new Date(item.expirationDate).toLocaleDateString()}
                </div>
              )}

              {item.notes && (
                <div className="text-sm text-slate-600 mt-2">{item.notes}</div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isAddingManual || !!editingItem} onOpenChange={(open) => {
        if (!open) {
          setIsAddingManual(false);
          setEditingItem(null);
          resetForm();
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Item" : "Add New Item"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Item Name</Label>
              <Input
                value={formData.itemName}
                onChange={(e) => setFormData(prev => ({ ...prev, itemName: e.target.value }))}
                placeholder="Enter item name"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Category</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vegetables">Vegetables</SelectItem>
                    <SelectItem value="proteins">Proteins</SelectItem>
                    <SelectItem value="grains">Grains</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                    <SelectItem value="pantry">Pantry</SelectItem>
                    <SelectItem value="spices">Spices</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Location</Label>
                <Select value={formData.location} onValueChange={(value) => setFormData(prev => ({ ...prev, location: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pantry">Pantry</SelectItem>
                    <SelectItem value="fridge">Fridge</SelectItem>
                    <SelectItem value="freezer">Freezer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Quantity</Label>
                <Input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
                />
              </div>
              <div>
                <Label>Unit</Label>
                <Select value={formData.unit} onValueChange={(value) => setFormData(prev => ({ ...prev, unit: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pieces">Pieces</SelectItem>
                    <SelectItem value="lbs">Pounds</SelectItem>
                    <SelectItem value="oz">Ounces</SelectItem>
                    <SelectItem value="cups">Cups</SelectItem>
                    <SelectItem value="grams">Grams</SelectItem>
                    <SelectItem value="bottles">Bottles</SelectItem>
                    <SelectItem value="heads">Heads</SelectItem>
                    <SelectItem value="bulbs">Bulbs</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Expiration Date (Optional)</Label>
              <Input
                type="date"
                value={formData.expirationDate}
                onChange={(e) => setFormData(prev => ({ ...prev, expirationDate: e.target.value }))}
              />
            </div>

            <div>
              <Label>Notes (Optional)</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any additional notes..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button 
                onClick={editingItem ? handleEdit : handleManualAdd}
                disabled={addItemMutation.isPending || updateItemMutation.isPending}
              >
                {editingItem ? "Update Item" : "Add Item"}
              </Button>
              <Button variant="outline" onClick={() => {
                setIsAddingManual(false);
                setEditingItem(null);
                resetForm();
              }}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}