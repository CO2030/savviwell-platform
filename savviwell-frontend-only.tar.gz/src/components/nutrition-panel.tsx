import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Star, Leaf, Droplets } from "lucide-react";

export function NutritionPanel() {
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
  });

  const { data: nutrition } = useQuery({
    queryKey: ["/api/nutrition/today"],
  });

  const calorieProgress = nutrition && user ? (nutrition.calories / user.dailyCalorieGoal) * 100 : 0;
  const proteinProgress = nutrition ? Math.min((nutrition.protein / 120) * 100, 100) : 0;
  const carbsProgress = nutrition ? Math.min((nutrition.carbs / 150) * 100, 100) : 0;
  const fatProgress = nutrition ? Math.min((nutrition.fat / 65) * 100, 100) : 0;

  const recommendations = [
    {
      icon: Leaf,
      title: "Add more fiber",
      description: "Try adding berries to your breakfast",
      color: "emerald",
    },
    {
      icon: Droplets,
      title: "Stay hydrated",
      description: "You're 2 glasses behind today",
      color: "blue",
    },
  ];

  const upcomingMeals = [
    {
      name: "Quinoa Power Bowl",
      type: "Dinner",
      calories: 450,
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40",
    },
    {
      name: "Berry Protein Smoothie",
      type: "Snack",
      calories: 180,
      image: "https://images.unsplash.com/photo-1553530666-ba11a7da3888?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40",
    },
  ];

  return (
    <div className="flex flex-col w-80 bg-white border-l border-slate-200">
      {/* Today's Nutrition */}
      <div className="p-6 border-b border-slate-200">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Today's Nutrition</h3>
        
        {/* Calorie Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">Calories</span>
            <span className="text-sm text-slate-600">
              {nutrition?.calories || 0} / {user?.dailyCalorieGoal || 2000}
            </span>
          </div>
          <Progress value={calorieProgress} className="h-2" />
        </div>

        {/* Macros */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center">
            <div className="text-lg font-bold text-blue-600">{nutrition?.carbs || 0}g</div>
            <div className="text-xs text-slate-500">Carbs</div>
            <Progress value={carbsProgress} className="h-1 mt-1" />
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-emerald-600">{nutrition?.protein || 0}g</div>
            <div className="text-xs text-slate-500">Protein</div>
            <Progress value={proteinProgress} className="h-1 mt-1" />
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-amber-600">{nutrition?.fat || 0}g</div>
            <div className="text-xs text-slate-500">Fat</div>
            <Progress value={fatProgress} className="h-1 mt-1" />
          </div>
        </div>

        {/* Health Score */}
        <Card className="bg-gradient-to-r from-emerald-50 to-blue-50 border-none">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">Health Score</span>
              <span className="text-2xl font-bold text-emerald-600">
                {nutrition?.healthScore || 8.5}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`h-4 w-4 ${
                    star <= Math.floor((nutrition?.healthScore || 8.5) / 2)
                      ? "text-emerald-500 fill-emerald-500"
                      : star === Math.ceil((nutrition?.healthScore || 8.5) / 2)
                      ? "text-emerald-500 fill-emerald-500/50"
                      : "text-slate-300"
                  }`}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <div className="p-6 border-b border-slate-200">
        <h4 className="text-sm font-semibold text-slate-800 mb-3">Recommendations</h4>
        <div className="space-y-3">
          {recommendations.map((rec, index) => (
            <Card
              key={index}
              className={`bg-${rec.color}-50 border-${rec.color}-200`}
            >
              <CardContent className="p-3 flex items-start space-x-3">
                <rec.icon className={`h-4 w-4 text-${rec.color}-500 mt-1 flex-shrink-0`} />
                <div>
                  <p className={`text-sm font-medium text-${rec.color}-800`}>{rec.title}</p>
                  <p className={`text-xs text-${rec.color}-600`}>{rec.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Upcoming Meals */}
      <div className="flex-1 p-6">
        <h4 className="text-sm font-semibold text-slate-800 mb-3">Upcoming Meals</h4>
        <div className="space-y-3">
          {upcomingMeals.map((meal, index) => (
            <Card key={index} className="bg-slate-50 border-slate-200">
              <CardContent className="p-3 flex items-center space-x-3">
                <img
                  src={meal.image}
                  alt={meal.name}
                  className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 truncate">{meal.name}</p>
                  <p className="text-xs text-slate-500">
                    {meal.type} • {meal.calories} cal
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
