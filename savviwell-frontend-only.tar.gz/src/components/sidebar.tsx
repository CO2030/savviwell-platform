import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { User, Users, Calendar, TrendingUp, Utensils, Clock, Settings, Package } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const isMobile = useIsMobile();

  const { data: user } = useQuery({
    queryKey: ["/api/user"],
  });

  const { data: conversations } = useQuery({
    queryKey: ["/api/conversations"],
  });

  const { data: todayNutrition } = useQuery({
    queryKey: ["/api/nutrition/today"],
  });

  const formatTime = (date: string) => {
    return new Date(date).toLocaleDateString();
  };

  return (
    <div className={`flex flex-col bg-gradient-to-b from-slate-50 to-white border-r border-slate-200/80 shadow-sm ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-slate-200/50 bg-white/80 backdrop-blur-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 via-purple-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg">
            <User className="text-white text-sm" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-slate-800">VoiceAI</h1>
            <p className="text-xs text-slate-500">Assistant</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" className="hover:bg-slate-100 rounded-xl">
          <Settings className="h-4 w-4 text-slate-600" />
        </Button>
      </div>

      {/* User Profile */}
      {user && (
        <div className="p-6 border-b border-slate-200/50">
          <div className="flex items-center space-x-4 mb-5">
            <Avatar className="w-14 h-14 border-2 border-white shadow-md">
              <AvatarImage src={user.profileImage} alt={user.name} />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-violet-500 text-white font-semibold">
                {user.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="font-semibold text-slate-800">{user.name}</p>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                <p className="text-sm text-slate-500 capitalize">{user.membershipType} Member</p>
              </div>
            </div>
          </div>

          {/* Health Stats */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 border-emerald-200/50 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-emerald-700">
                      {todayNutrition?.calories || 0}
                    </div>
                    <div className="text-xs text-emerald-600">Calories Today</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100/50 border-blue-200/50 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                    <Calendar className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-blue-700">
                      {Math.floor(Math.random() * 20) + 1}
                    </div>
                    <div className="text-xs text-blue-600">Day Streak</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="p-6 border-b border-slate-200/50">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center">
          <div className="w-1 h-4 bg-gradient-to-b from-blue-500 to-violet-500 rounded-full mr-2"></div>
          Navigation
        </h3>
        <div className="space-y-1">
          <Link href="/">
            <Button 
              variant={location === "/" ? "default" : "ghost"} 
              className={`w-full justify-start h-11 rounded-xl transition-all ${
                location === "/" 
                  ? "bg-gradient-to-r from-blue-500 to-violet-500 text-white shadow-lg hover:shadow-xl" 
                  : "hover:bg-slate-100 text-slate-700"
              }`}
            >
              <User className="mr-3 h-4 w-4" />
              <span className="text-sm font-medium">AI Assistant</span>
            </Button>
          </Link>
          <Link href="/meal-planning">
            <Button 
              variant={location === "/meal-planning" ? "default" : "ghost"} 
              className={`w-full justify-start h-11 rounded-xl transition-all ${
                location === "/meal-planning" 
                  ? "bg-gradient-to-r from-blue-500 to-violet-500 text-white shadow-lg hover:shadow-xl" 
                  : "hover:bg-slate-100 text-slate-700"
              }`}
            >
              <Utensils className="mr-3 h-4 w-4" />
              <span className="text-sm font-medium">Meal Planning</span>
            </Button>
          </Link>
          <Link href="/family-profiles">
            <Button 
              variant={location === "/family-profiles" ? "default" : "ghost"} 
              className={`w-full justify-start h-11 rounded-xl transition-all ${
                location === "/family-profiles" 
                  ? "bg-gradient-to-r from-blue-500 to-violet-500 text-white shadow-lg hover:shadow-xl" 
                  : "hover:bg-slate-100 text-slate-700"
              }`}
            >
              <Users className="mr-3 h-4 w-4" />
              <span className="text-sm font-medium">Family Profiles</span>
            </Button>
          </Link>
          <Link href="/pantry">
            <Button 
              variant={location === "/pantry" ? "default" : "ghost"} 
              className={`w-full justify-start h-11 rounded-xl transition-all ${
                location === "/pantry" 
                  ? "bg-gradient-to-r from-blue-500 to-violet-500 text-white shadow-lg hover:shadow-xl" 
                  : "hover:bg-slate-100 text-slate-700"
              }`}
            >
              <Package className="mr-3 h-4 w-4" />
              <span className="text-sm font-medium">Smart Pantry</span>
            </Button>
          </Link>
        </div>
      </div>

      {/* Recent Conversations */}
      <div className="flex-1 p-6 overflow-y-auto">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center">
          <div className="w-1 h-4 bg-gradient-to-b from-emerald-500 to-blue-500 rounded-full mr-2"></div>
          Recent Conversations
        </h3>
        <div className="space-y-2">
          {conversations?.map((conversation: any) => (
            <Button
              key={conversation.id}
              variant="ghost"
              className="w-full justify-start p-4 h-auto rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200 hover:shadow-sm"
            >
              <div className="text-left flex-1">
                <p className="text-sm font-medium text-slate-800 line-clamp-1 mb-1">
                  {conversation.title}
                </p>
                <p className="text-xs text-slate-500 flex items-center">
                  <Clock className="mr-1 h-3 w-3" />
                  {formatTime(conversation.updatedAt)}
                </p>
              </div>
            </Button>
          )) || (
            <div className="text-center py-8">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Clock className="w-6 h-6 text-slate-400" />
              </div>
              <p className="text-sm text-slate-500">No conversations yet</p>
              <p className="text-xs text-slate-400 mt-1">Start chatting to see your history</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}