import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { apiRequest } from "@/lib/queryClient";
import { 
  Check, 
  X, 
  ShoppingCart, 
  Mail, 
  Eye, 
  ChefHat,
  Clock,
  Users,
  Edit,
  Trash2,
  RefreshCw,
  Plus,
  Wand2,
  Camera,
  Upload,
  Sparkles,
  Heart,
  Target,
  MoreVertical,
  Filter,
  SortAsc,
  Archive,
  Copy,
  Share,
  Settings
} from "lucide-react";
import { format, addDays, startOfWeek } from "date-fns";
import { DailyWellnessTips } from "./daily-wellness-tips";

interface MealPlan {
  id: number;
  title: string;
  description: string;
  startDate: Date;
  endDate: Date;
  totalCalories: number;
  meals: any;
  isActive: boolean;
}

interface PendingMeal {
  id?: string;
  date: string;
  mealType: "breakfast" | "lunch" | "dinner";
  name: string;
  calories: number;
  ingredients: string[];
  instructions: string[];
  approved: boolean;
  isUserCreated?: boolean;
  image?: string;
}

interface MealFormData {
  name: string;
  calories: string;
  ingredients: string;
  instructions: string;
  mealType: "breakfast" | "lunch" | "dinner";
  image?: string;
}

export function MealCalendar() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<"calendar" | "list" | "wellness">("calendar");
  const [editingMeal, setEditingMeal] = useState<PendingMeal | null>(null);
  const [isCreateMealOpen, setIsCreateMealOpen] = useState(false);
  const [isGenerateMealOpen, setIsGenerateMealOpen] = useState(false);
  const [mealFormData, setMealFormData] = useState<MealFormData>({
    name: "",
    calories: "",
    ingredients: "",
    instructions: "",
    mealType: "dinner"
  });
  const [generatePrompt, setGeneratePrompt] = useState("");
  const [isScanningMeal, setIsScanningMeal] = useState(false);
  const [mealScanResult, setMealScanResult] = useState<any>(null);
  const [pendingMeals, setPendingMeals] = useState<PendingMeal[]>([]);
  const [showMealGenerator, setShowMealGenerator] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"date" | "calories" | "name">("date");
  const [mealGeneratorForm, setMealGeneratorForm] = useState({
    mealType: 'breakfast',
    cuisine: '',
    spiciness: 'mild',
    easiness: 'intermediate',
    portions: 2,
    dietaryNeeds: [] as string[],
    planDuration: 'weekly',
    mealsPerDay: 3
  });

  const queryClient = useQueryClient();

  const { data: mealPlans = [] } = useQuery({
    queryKey: ["/api/meal-plans"],
  });

  const { data: meals = [], isLoading: mealsLoading } = useQuery({
    queryKey: ["/api/meals"],
    select: (data) => data || []
  });

  // Update local state when API data changes
  useEffect(() => {
    if (meals.length > 0) {
      setPendingMeals(meals);
    }
  }, [meals]);

  // Handle meal scanning events from form
  useEffect(() => {
    const handleMealScan = () => {
      startMealCamera();
    };

    const handleMealUpload = () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file) {
          processMealImage(file);
        }
      };
      input.click();
    };

    window.addEventListener('startMealScan', handleMealScan);
    window.addEventListener('uploadMealImage', handleMealUpload);

    return () => {
      window.removeEventListener('startMealScan', handleMealScan);
      window.removeEventListener('uploadMealImage', handleMealUpload);
    };
  }, []);

  const startMealCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'environment'
        }
      });

      setIsScanningMeal(true);

      // Create a temporary video element for meal scanning
      const video = document.createElement('video');
      video.srcObject = stream;
      video.play();

      video.onloadedmetadata = () => {
        // Auto-capture after a short delay
        setTimeout(() => {
          captureMealImage(video, stream);
        }, 2000);
      };

    } catch (error) {
      console.error("Error accessing camera for meal scan:", error);
      setIsScanningMeal(false);
    }
  };

  const captureMealImage = (video: HTMLVideoElement, stream: MediaStream) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx || !video.videoWidth || !video.videoHeight) {
      stream.getTracks().forEach(track => track.stop());
      setIsScanningMeal(false);
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);

    const imageData = canvas.toDataURL('image/jpeg', 0.8);

    // Stop camera
    stream.getTracks().forEach(track => track.stop());

    // Send to scan
    scanMealMutation.mutate(imageData);
  };

  const processMealImage = async (file: File) => {
    try {
      setIsScanningMeal(true);

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        const maxWidth = 800;
        const maxHeight = 600;
        let { width, height } = img;

        if (width > height) {
          if (width > maxWidth) {
            height = (height * maxWidth) / width;
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = (width * maxHeight) / height;
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        ctx?.drawImage(img, 0, 0, width, height);

        const imageData = canvas.toDataURL('image/jpeg', 0.8);
        scanMealMutation.mutate(imageData);
      };

      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);

    } catch (error) {
      console.error('Error processing meal image:', error);
      setIsScanningMeal(false);
    }
  };

  const approveMealMutation = useMutation({
    mutationFn: async (meal: PendingMeal) => {
      const response = await apiRequest("PUT", `/api/meals/${meal.id}`, { approved: true });
      return response.json();
    },
    onSuccess: (approvedMeal) => {
      setPendingMeals(prev => 
        prev.map(meal => 
          meal.id === approvedMeal.id ? approvedMeal : meal
        )
      );
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
    }
  });

  const deleteMealMutation = useMutation({
    mutationFn: async (mealId: string) => {
      const response = await apiRequest("DELETE", `/api/meals/${mealId}`);
      return response.json();
    },
    onSuccess: (result) => {
      setPendingMeals(prev => prev.filter(meal => meal.id !== result.id));
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
    }
  });

  const updateMealMutation = useMutation({
    mutationFn: async (updatedMeal: PendingMeal) => {
      const { id, ...updateData } = updatedMeal;
      const response = await apiRequest("PUT", `/api/meals/${id}`, updateData);
      return response.json();
    },
    onSuccess: (updatedMeal) => {
      setPendingMeals(prev => 
        prev.map(meal => 
          meal.id === updatedMeal.id ? updatedMeal : meal
        )
      );
      setEditingMeal(null);
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
    }
  });

  const createMealMutation = useMutation({
    mutationFn: async (newMeal: Omit<PendingMeal, 'id'>) => {
      const response = await apiRequest("POST", "/api/meals", {
        ...newMeal,
        isUserCreated: true
      });
      return response.json();
    },
    onSuccess: (newMeal) => {
      setPendingMeals(prev => [...prev, newMeal]);
      setIsCreateMealOpen(false);
      resetMealForm();
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
    }
  });

  const generateMealMutation = useMutation({
    mutationFn: async (generationData: any) => {
      const prompt = `Generate a ${generationData.mealType} recipe for ${generationData.portions} people. 
        Cuisine: ${generationData.cuisine || 'Any'}, 
        Spiciness: ${generationData.spiciness}, 
        Difficulty: ${generationData.easiness},
        Dietary requirements: ${generationData.dietaryNeeds.join(', ') || 'None'}`;

      const response = await apiRequest("POST", "/api/meals/generate", {
        prompt,
        date: format(selectedDate, "yyyy-MM-dd"),
        mealType: generationData.mealType,
        cuisine: generationData.cuisine,
        spiciness: generationData.spiciness,
        easiness: generationData.easiness,
        portions: generationData.portions,
        dietaryNeeds: generationData.dietaryNeeds
      });
      return response.json();
    },
    onSuccess: (newMeal) => {
      setPendingMeals(prev => [...prev, newMeal]);
      queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
      setShowMealGenerator(false);
      setMealGeneratorForm({
        mealType: 'breakfast',
        cuisine: '',
        spiciness: 'mild',
        easiness: 'intermediate',
        portions: 2,
        dietaryNeeds: [],
        planDuration: 'weekly',
        mealsPerDay: 3
      });
    }
  });

  const generateMealPlanMutation = useMutation({
    mutationFn: async (planData: any) => {
      const response = await apiRequest("POST", "/api/ai/meal-plan", {
        planDuration: planData.planDuration,
        mealsPerDay: planData.mealsPerDay,
        cuisine: planData.cuisine,
        dietaryNeeds: planData.dietaryNeeds,
        spiciness: planData.spiciness,
        easiness: planData.easiness,
        portions: planData.portions
      });
      return response.json();
    },
    onSuccess: (mealPlan) => {
      console.log('Generated meal plan:', mealPlan);
      
      // Create individual meals from the plan
      if (mealPlan.days && Array.isArray(mealPlan.days)) {
        const today = new Date();
        
        mealPlan.days.forEach((day: any, dayIndex: number) => {
          if (day.meals && Array.isArray(day.meals)) {
            day.meals.forEach((meal: any) => {
              const mealDate = new Date(today);
              mealDate.setDate(today.getDate() + dayIndex);
              const dateStr = mealDate.toISOString().split('T')[0];
              
              // Convert structured ingredients to simple strings for storage
              const ingredientsList = meal.ingredients?.map((ing: any) => {
                if (typeof ing === 'object' && ing.item) {
                  return `${ing.quantity} ${ing.unit} ${ing.item}`;
                }
                return typeof ing === 'string' ? ing : 'Unknown ingredient';
              }) || [];

              createMealMutation.mutate({
                date: dateStr,
                name: meal.name,
                calories: meal.calories || 400,
                ingredients: ingredientsList,
                instructions: meal.instructions || [],
                mealType: meal.mealType || 'dinner',
                approved: false,
                isUserCreated: false
              });
            });
          }
        });
      }
    },
    onError: (error) => {
      console.error('Failed to generate meal plan:', error);
    }
  });

  const scanMealMutation = useMutation({
    mutationFn: async (imageData: string) => {
      const response = await apiRequest("POST", "/api/pantry/scan", { image: imageData });
      const result = await response.json();

      if (!result.success) {
        throw new Error(result.message || 'Scan failed');
      }

      return result;
    },
    onSuccess: (result) => {
      if (result.type === "meal" && result.meal) {
        setMealScanResult(result);
        // Auto-fill form with scanned meal data
        setMealFormData(prev => ({
          ...prev,
          name: result.meal.name,
          calories: result.meal.calories.toString(),
          ingredients: result.meal.ingredients.join("\n"),
          instructions: [`Prepared ${result.meal.name}`, "See ingredients for details"].join("\n")
        }));
      }
      setIsScanningMeal(false);
    },
    onError: (error: any) => {
      console.error("Meal scan failed:", error);
      setIsScanningMeal(false);
    }
  });

  const resetMealForm = () => {
    setMealFormData({
      name: "",
      calories: "",
      ingredients: "",
      instructions: "",
      mealType: "dinner",
      image: undefined
    });
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target?.result as string;
        setMealFormData(prev => ({ ...prev, image: imageData }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditMeal = (meal: PendingMeal) => {
    setEditingMeal(meal);
    setMealFormData({
      name: meal.name,
      calories: meal.calories.toString(),
      ingredients: meal.ingredients.join("\n"),
      instructions: meal.instructions.join("\n"),
      mealType: meal.mealType,
      image: meal.image
    });
  };

  const handleSaveEdit = () => {
    if (!editingMeal) return;

    const updatedMeal: PendingMeal = {
      ...editingMeal,
      name: mealFormData.name,
      calories: parseInt(mealFormData.calories) || 0,
      ingredients: mealFormData.ingredients.split("\n").filter(i => i.trim()),
      instructions: mealFormData.instructions.split("\n").filter(i => i.trim()),
      mealType: mealFormData.mealType,
      image: mealFormData.image,
      approved: false // Reset approval when edited
    };

    updateMealMutation.mutate(updatedMeal);
  };

  const handleCreateMeal = () => {
    const newMeal: Omit<PendingMeal, 'id'> = {
      date: format(selectedDate, "yyyy-MM-dd"),
      name: mealFormData.name,
      calories: parseInt(mealFormData.calories) || 0,
      ingredients: mealFormData.ingredients.split("\n").filter(i => i.trim()),
      instructions: mealFormData.instructions.split("\n").filter(i => i.trim()),
      mealType: mealFormData.mealType,
      image: mealFormData.image,
      approved: false,
      isUserCreated: true
    };

    createMealMutation.mutate(newMeal);
  };

  const generateGroceryList = () => {
    const categorizedIngredients: { [key: string]: { item: string, quantity: string, estimated: boolean }[] } = {
      produce: [],
      dairy: [],
      meat: [],
      pantry: [],
      spices: [],
      other: [],
    };

    // Enhanced categorization with quantity parsing
    const categorizeIngredient = (ingredient: string) => {
      const lowerIngredient = ingredient.toLowerCase();
      
      // Parse quantity and item from ingredient string (e.g., "2 cups rice" -> quantity: "2 cups", item: "rice")
      const quantityMatch = ingredient.match(/^(\d+(?:\.\d+)?\s*(?:cups?|tbsp|tsp|lbs?|oz|pieces?|cloves?|heads?)?)\s+(.+)$/i);
      const quantity = quantityMatch ? quantityMatch[1] : "1";
      const item = quantityMatch ? quantityMatch[2] : ingredient;
      
      if (lowerIngredient.includes('apple') || lowerIngredient.includes('banana') || lowerIngredient.includes('orange') || 
          lowerIngredient.includes('lettuce') || lowerIngredient.includes('spinach') || lowerIngredient.includes('tomato') || 
          lowerIngredient.includes('onion') || lowerIngredient.includes('garlic') || lowerIngredient.includes('potato') || 
          lowerIngredient.includes('carrot') || lowerIngredient.includes('broccoli') || lowerIngredient.includes('pepper') ||
          lowerIngredient.includes('cilantro') || lowerIngredient.includes('lemon') || lowerIngredient.includes('lime')) {
        return { category: 'produce', item, quantity, estimated: !quantityMatch };
      } else if (lowerIngredient.includes('milk') || lowerIngredient.includes('cheese') || lowerIngredient.includes('yogurt') || 
                lowerIngredient.includes('butter') || lowerIngredient.includes('cream')) {
        return { category: 'dairy', item, quantity, estimated: !quantityMatch };
      } else if (lowerIngredient.includes('chicken') || lowerIngredient.includes('beef') || lowerIngredient.includes('pork') || 
                lowerIngredient.includes('fish') || lowerIngredient.includes('egg') || lowerIngredient.includes('salmon') ||
                lowerIngredient.includes('turkey') || lowerIngredient.includes('shrimp')) {
        return { category: 'meat', item, quantity, estimated: !quantityMatch };
      } else if (lowerIngredient.includes('rice') || lowerIngredient.includes('pasta') || lowerIngredient.includes('bread') || 
                lowerIngredient.includes('flour') || lowerIngredient.includes('sugar') || lowerIngredient.includes('oil') || 
                lowerIngredient.includes('canned') || lowerIngredient.includes('quinoa') || lowerIngredient.includes('oats')) {
        return { category: 'pantry', item, quantity, estimated: !quantityMatch };
      } else if (lowerIngredient.includes('salt') || lowerIngredient.includes('pepper') || lowerIngredient.includes('herbs') || 
                lowerIngredient.includes('spices') || lowerIngredient.includes('oregano') || lowerIngredient.includes('basil') ||
                lowerIngredient.includes('cumin') || lowerIngredient.includes('paprika')) {
        return { category: 'spices', item, quantity, estimated: !quantityMatch };
      } else {
        return { category: 'other', item, quantity, estimated: !quantityMatch };
      }
    };

    // Aggregate ingredients from approved meals
    const ingredientMap = new Map<string, { item: string, totalQuantity: string, category: string, estimated: boolean }>();

    pendingMeals
      .filter(meal => meal.approved)
      .forEach(meal => {
        meal.ingredients.forEach(ingredient => {
          const categorized = categorizeIngredient(ingredient);
          const key = categorized.item.toLowerCase();
          
          if (ingredientMap.has(key)) {
            const existing = ingredientMap.get(key)!;
            // For now, just concatenate quantities - could be enhanced with proper unit conversion
            existing.totalQuantity = existing.estimated && !categorized.estimated ? 
              categorized.quantity : `${existing.totalQuantity}, ${categorized.quantity}`;
            existing.estimated = existing.estimated && categorized.estimated;
          } else {
            ingredientMap.set(key, {
              item: categorized.item,
              totalQuantity: categorized.quantity,
              category: categorized.category,
              estimated: categorized.estimated
            });
          }
        });
      });

    // Group by category
    ingredientMap.forEach(ingredient => {
      categorizedIngredients[ingredient.category].push({
        item: ingredient.item,
        quantity: ingredient.totalQuantity,
        estimated: ingredient.estimated
      });
    });

    // Sort within categories
    Object.keys(categorizedIngredients).forEach(key => {
      categorizedIngredients[key].sort((a, b) => a.item.localeCompare(b.item));
    });

    return categorizedIngredients;
  };

  const getMealsForDate = (date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    let filtered = pendingMeals.filter(meal => meal.date === dateStr);

    // Apply category filter
    if (selectedCategory !== "all") {
      filtered = filtered.filter(meal => meal.mealType === selectedCategory);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "calories":
          return b.calories - a.calories;
        case "name":
          return a.name.localeCompare(b.name);
        case "date":
        default:
          return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
    });

    return filtered;
  };

  const getFilteredMeals = () => {
    let filtered = pendingMeals;

    if (selectedCategory !== "all") {
      filtered = filtered.filter(meal => meal.mealType === selectedCategory);
    }

    filtered.sort((a, b) => {
      switch (sortBy) {
        case "calories":
          return b.calories - a.calories;
        case "name":
          return a.name.localeCompare(b.name);
        case "date":
        default:
          return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
    });

    return filtered;
  };

  const getCategoryStats = () => {
    const stats = {
      all: pendingMeals.length,
      breakfast: pendingMeals.filter(m => m.mealType === "breakfast").length,
      lunch: pendingMeals.filter(m => m.mealType === "lunch").length,
      dinner: pendingMeals.filter(m => m.mealType === "dinner").length,
    };
    return stats;
  };

  const getWeekMeals = () => {
    const weekStart = startOfWeek(selectedDate);
    const weekMeals = [];

    for (let i = 0; i < 7; i++) {
      const date = addDays(weekStart, i);
      const meals = getMealsForDate(date);
      weekMeals.push({
        date,
        meals
      });
    }

    return weekMeals;
  };

  const MealCard = ({ meal }: { meal: PendingMeal }) => (
    <Card className={`mb-3 ${meal.approved ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            {meal.image && (
              <div className="mb-3">
                <img
                  src={meal.image}
                  alt={meal.name}
                  className="w-full h-32 object-cover rounded-lg border border-slate-200"
                />
              </div>
            )}
            <div className="flex items-center space-x-2 mb-2">
              <ChefHat className="h-4 w-4 text-slate-600" />
              <span className="font-medium text-slate-800">{meal.name}</span>
              <Badge variant="secondary" className="text-xs">
                {meal.mealType}
              </Badge>
              {meal.isUserCreated && (
                <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700">
                  Custom
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-4 text-sm text-slate-600 mb-3">
              <span className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                {meal.calories} cal
              </span>
              <span className="flex items-center">
                <Users className="h-3 w-3 mr-1" />
                1 serving
              </span>
            </div>
          </div>

          <div className="flex space-x-2">
            {/* Quick Action Buttons */}
            {!meal.approved && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => approveMealMutation.mutate(meal)}
                className="bg-green-100 text-green-700 border-green-300 hover:bg-green-200"
              >
                <Check className="h-4 w-4" />
              </Button>
            )}

            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline">
                  <Eye className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>{meal.name}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {meal.image && (
                    <div>
                      <img
                        src={meal.image}
                        alt={meal.name}
                        className="w-full h-48 object-cover rounded-lg border border-slate-200"
                      />
                    </div>
                  )}
                  <div>
                    <h4 className="font-medium mb-2">Ingredients:</h4>
                    <ul className="space-y-1 text-sm text-slate-600">
                      {meal.ingredients.map((ingredient, idx) => (
                        <li key={idx} className="flex items-center">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mr-2" />
                          {ingredient}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="font-medium mb-2">Instructions:</h4>
                    <ol className="space-y-1 text-sm text-slate-600">
                      {meal.instructions.map((step, idx) => (
                        <li key={idx} className="flex">
                          <span className="bg-blue-100 text-blue-700 rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">
                            {idx + 1}
                          </span>
                          {step}
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Hamburger Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>Meal Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />

                <DropdownMenuItem onClick={() => handleEditMeal(meal)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Meal
                </DropdownMenuItem>

                <DropdownMenuItem onClick={() => navigator.clipboard.writeText(JSON.stringify(meal, null, 2))}>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Recipe
                </DropdownMenuItem>

                <DropdownMenuItem onClick={() => saveTipToLibraryMutation.mutate({
                  id: meal.id!,
                  title: `Recipe: ${meal.name}`,
                  content: `Delicious ${meal.mealType} with ${meal.calories} calories`,
                  category: "nutrition",
                  tags: [meal.mealType, "recipe"],
                  difficulty: "easy",
                  estimatedTime: "30 min",
                  benefits: [`${meal.calories} calories`, "Nutritious meal"],
                  createdAt: meal.date || new Date().toISOString()
                })}>
                  <Archive className="h-4 w-4 mr-2" />
                  Save to Library
                </DropdownMenuItem>

                <DropdownMenuSeparator />

                <DropdownMenuItem 
                  onClick={() => deleteMealMutation.mutate(meal.id!)}
                  className="text-red-600 focus:text-red-600"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Meal
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {meal.approved && (
          <Badge className="bg-green-100 text-green-700">
            <Check className="h-3 w-3 mr-1" />
            Approved
          </Badge>
        )}
      </CardContent>
    </Card>
  );

  const MealForm = ({ onSave, onCancel, isEdit = false }: { onSave: () => void; onCancel: () => void; isEdit?: boolean }) => (
    <div className="space-y-4">
      {/* Meal Scanning Section */}
      {!isEdit && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <ChefHat className="h-4 w-4 text-blue-600" />
              <span className="font-medium text-blue-800">Scan or Upload Meal Image</span>
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  // Trigger camera scanning for meal
                  const scanEvent = new CustomEvent('startMealScan');
                  window.dispatchEvent(scanEvent);
                }}
                className="flex-1"
              >
                <Camera className="h-4 w-4 mr-2" />
                Scan Meal
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  // Trigger file upload for meal
                  const uploadEvent = new CustomEvent('uploadMealImage');
                  window.dispatchEvent(uploadEvent);
                }}
                className="flex-1"
              >
                <Upload className="h-4 w-4 mr-2" />
                Upload Photo
              </Button>
            </div>
            <p className="text-xs text-blue-600 mt-2">
              Scan a prepared meal to auto-fill nutritional information
            </p>
          </CardContent>
        </Card>
      )}

      {/* Scan Result Display */}
      {mealScanResult && mealScanResult.type === "meal" && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Check className="h-4 w-4 text-green-600" />
              <span className="font-medium text-green-800">Meal Detected!</span>
            </div>
            <div className="text-sm text-green-700">
              <p className="mb-1">Found: {mealScanResult.meal.name}</p>
              <p>Calories: {mealScanResult.meal.calories} | Protein: {mealScanResult.meal.protein}g</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Scanning Status */}
      {isScanningMeal && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" />
              <span className="text-blue-800">Analyzing meal image...</span>
            </div>
          </CardContent>
        </Card>
      )}

      <div>
        <Label>Meal Name</Label>
        <Input
          value={mealFormData.name}
          onChange={(e) => setMealFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="Enter meal name"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Calories</Label>
          <Input
            type="number"
            value={mealFormData.calories}
            onChange={(e) => setMealFormData(prev => ({ ...prev, calories: e.target.value }))}
            placeholder="0"
          />
        </div>
        <div>
          <Label>Meal Type</Label>
          <Select value={mealFormData.mealType} onValueChange={(value: "breakfast" | "lunch" | "dinner") => setMealFormData(prev => ({ ...prev, mealType: value }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="breakfast">Breakfast</SelectItem>
              <SelectItem value="lunch">Lunch</SelectItem>
              <SelectItem value="dinner">Dinner</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label>Ingredients (one per line)</Label>
        <Textarea
          value={mealFormData.ingredients}
          onChange={(e) => setMealFormData(prev => ({ ...prev, ingredients: e.target.value }))}
          placeholder="Chicken breast (6oz)&#10;Rice (1 cup)&#10;Broccoli (1 cup)"
          rows={4}
        />
      </div>

      <div>
        <Label>Instructions (one per line)</Label>
        <Textarea
          value={mealFormData.instructions}
          onChange={(e) => setMealFormData(prev => ({ ...prev, instructions: e.target.value }))}
          placeholder="Season chicken with salt and pepper&#10;Grill for 6-8 minutes per side&#10;Cook rice according to package directions"
          rows={4}
        />
      </div>

      <div>
        <Label>Meal Image (Optional)</Label>
        <div className="space-y-3">
          <Input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="cursor-pointer"
          />
          {mealFormData.image && (
            <div className="relative">
              <img
                src={mealFormData.image}
                alt="Meal preview"
                className="w-full h-40 object-cover rounded-lg border border-slate-200"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setMealFormData(prev => ({ ...prev, image: undefined }))}
                className="absolute top-2 right-2 bg-white/80 hover:bg-white"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="flex space-x-2">
        <Button onClick={onSave} disabled={!mealFormData.name.trim()}>
          {isEdit ? "Save Changes" : "Create Meal"}
        </Button>
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </div>
  );

  const handleDietaryToggle = (dietary: string) => {
    setMealGeneratorForm(prev => ({
      ...prev,
      dietaryNeeds: prev.dietaryNeeds.includes(dietary)
        ? prev.dietaryNeeds.filter(d => d !== dietary)
        : [...prev.dietaryNeeds, dietary]
    }));
  };

  const handleGenerateMeal = () => {
    generateMealMutation.mutate(mealGeneratorForm);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-slate-200">
        <div>
          <h2 className="text-xl font-semibold text-slate-800">Meal Planning</h2>
          <p className="text-sm text-slate-500">Review, edit, and manage your weekly meals</p>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === "calendar" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("calendar")}
          >
            Calendar
          </Button>
          <Button
            variant={viewMode === "list" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("list")}
          >
            List
          </Button>
          <Button
            variant={viewMode === "wellness" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("wellness")}
          >
            <Heart className="h-4 w-4 mr-2" />
            Wellness
          </Button>

          {/* Category Filter Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                {selectedCategory === "all" ? "All Meals" : selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}
                {(() => {
                  const stats = getCategoryStats();
                  return ` (${stats[selectedCategory as keyof typeof stats]})`;
                })()}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Filter by Category</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setSelectedCategory("all")}>
                All Meals ({getCategoryStats().all})
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSelectedCategory("breakfast")}>
                Breakfast ({getCategoryStats().breakfast})
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSelectedCategory("lunch")}>
                Lunch ({getCategoryStats().lunch})
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSelectedCategory("dinner")}>
                Dinner ({getCategoryStats().dinner})
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Sort Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <SortAsc className="h-4 w-4 mr-2" />
                Sort
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Sort by</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setSortBy("date")}>
                Date
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy("name")}>
                Name
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy("calories")}>
                Calories
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Dialog open={isCreateMealOpen} onOpenChange={setIsCreateMealOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" onClick={() => resetMealForm()}>
                <Plus className="h-4 w-4 mr-2" />
                Add Meal
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Custom Meal</DialogTitle>
              </DialogHeader>
              <MealForm onSave={handleCreateMeal} onCancel={() => setIsCreateMealOpen(false)} />
            </DialogContent>
          </Dialog>

          <Dialog open={isGenerateMealOpen} onOpenChange={setIsGenerateMealOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Wand2 className="h-4 w-4 mr-2" />
                Generate Meal
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>AI Generate Meal</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Describe what kind of meal you want</Label>
                  <Textarea
                    value={generatePrompt}
                    onChange={(e) => setGeneratePrompt(e.target.value)}
                    placeholder="E.g., 'A healthy dinner with chicken and vegetables, under 500 calories'"
                    rows={3}
                  />
                </div>
                <div className="flex space-x-2">
                  <Button 
                    onClick={() => generateMealMutation.mutate({
                      prompt: generatePrompt,
                      date: format(selectedDate, "yyyy-MM-dd"),
                      mealType: "dinner"
                    })}
                    disabled={!generatePrompt.trim()}
                  >
                    Generate Meal
                  </Button>
                  <Button variant="outline" onClick={() => setIsGenerateMealOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-emerald-600 hover:bg-emerald-700">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Grocery List
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Weekly Grocery List</DialogTitle>
                </DialogHeader>
                <ScrollArea className="h-96">
                  <div className="space-y-4">
                    {Object.entries(generateGroceryList()).map(([category, items]) => 
                      items.length > 0 && (
                        <div key={category} className="space-y-2">
                          <h3 className="font-semibold text-slate-700 capitalize border-b pb-1">
                            {category.replace(/([A-Z])/g, ' $1').trim()} ({items.length} items)
                          </h3>
                          {items.map((ingredient, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                              <div className="flex items-center flex-1">
                                <div className="w-2 h-2 bg-emerald-500 rounded-full mr-3" />
                                <div className="flex-1">
                                  <span className="font-medium">{ingredient.item}</span>
                                  <div className="text-sm text-slate-600">
                                    {ingredient.quantity}
                                    {ingredient.estimated && (
                                      <span className="text-orange-500 ml-1">(estimated)</span>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <span className="text-xs text-slate-500">✓</span>
                            </div>
                          ))}
                        </div>
                      )
                    )}
                  </div>
                </ScrollArea>
                <div className="flex space-x-2 pt-4">
                  <Button variant="outline" className="flex-1">
                    <Mail className="h-4 w-4 mr-2" />
                    Email List
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Export PDF
                  </Button>
                  <Button variant="outline" className="flex-1">
                    📱 Share List
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
        </div>
      </div>

      {/* Edit Meal Dialog */}
      <Dialog open={!!editingMeal} onOpenChange={(open) => !open && setEditingMeal(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Meal</DialogTitle>
          </DialogHeader>
          <MealForm onSave={handleSaveEdit} onCancel={() => setEditingMeal(null)} isEdit />
        </DialogContent>
      </Dialog>

      {/* Meal Generator Dialog */}
      <Dialog open={showMealGenerator} onOpenChange={setShowMealGenerator}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Generate Meal with AI</DialogTitle>
            <DialogDescription>
              Configure your meal preferences and let AI create the perfect recipe for you.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Meal Type Selection */}
            <div>
              <Label className="text-base font-medium">Meal Type</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {['breakfast', 'lunch', 'dinner', 'entree', 'main', 'dessert'].map((type) => (
                  <Button
                    key={type}
                    variant={mealGeneratorForm.mealType === type ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setMealGeneratorForm(prev => ({ ...prev, mealType: type }))}
                    className="capitalize"
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>

            {/* Cuisine Type */}
            <div>
              <Label htmlFor="cuisine" className="text-base font-medium">Cuisine Type</Label>
              <Input
                id="cuisine"
                placeholder="e.g., Japanese, Italian, Ethiopian"
                value={mealGeneratorForm.cuisine}
                onChange={(e) => setMealGeneratorForm(prev => ({ ...prev, cuisine: e.target.value }))}
                className="mt-2"
              />
            </div>

            {/* Spiciness Level */}
            <div>
              <Label className="text-base font-medium">Spiciness Level</Label>
              <div className="flex gap-2 mt-2">
                {['mild', 'medium', 'hot'].map((level) => (
                  <Button
                    key={level}
                    variant={mealGeneratorForm.spiciness === level ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setMealGeneratorForm(prev => ({ ...prev, spiciness: level }))}
                    className="capitalize"
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>

            {/* Easiness */}
            <div>
              <Label className="text-base font-medium">Easiness</Label>
              <div className="flex gap-2 mt-2">
                {['easy', 'intermediate', 'difficult'].map((level) => (
                  <Button
                    key={level}
                    variant={mealGeneratorForm.easiness === level ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setMealGeneratorForm(prev => ({ ...prev, easiness: level }))}
                    className="capitalize"
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>

            {/* Portions */}
            <div>
              <Label htmlFor="portions" className="text-base font-medium">Portions: {mealGeneratorForm.portions}</Label>
              <div className="flex items-center space-x-4 mt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMealGeneratorForm(prev => ({ ...prev, portions: Math.max(1, prev.portions - 1) }))}
                  disabled={mealGeneratorForm.portions <= 1}
                >
                  -
                </Button>
                <div className="w-16 text-center font-semibold">{mealGeneratorForm.portions}</div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMealGeneratorForm(prev => ({ ...prev, portions: Math.min(12, prev.portions + 1) }))}
                  disabled={mealGeneratorForm.portions >= 12}
                >
                  +
                </Button>
              </div>
            </div>

            {/* Dietary Needs */}
            <div>
              <Label className="text-base font-medium">Dietary Needs</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {['none', 'paleo', 'ketogenic', 'vegetarian', 'vegan', 'gluten-free'].map((diet) => (
                  <Button
                    key={diet}
                    variant={mealGeneratorForm.dietaryNeeds.includes(diet) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleDietaryToggle(diet)}
                    className="capitalize"
                  >
                    {diet === 'gluten-free' ? 'Gluten-Free' : diet}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMealGenerator(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleGenerateMeal}
              disabled={generateMealMutation.isPending}
              className="flex items-center space-x-2"
            >
              {generateMealMutation.isPending && <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>}
              <Sparkles className="h-4 w-4" />
              <span>Generate Meal</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Meal Details Dialog */}
      <div className="flex-1 p-6">
        {viewMode === "wellness" ? (
          <DailyWellnessTips />
        ) : viewMode === "calendar" ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Calendar */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="text-lg">Select Date</CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>

            {/* Selected Day Meals */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">
                  Meals for {format(selectedDate, "EEEE, MMMM d")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  {mealsLoading ? (
                    <div className="text-center py-8">
                      <RefreshCw className="h-8 w-8 mx-auto animate-spin text-blue-500 mb-4" />
                      <p className="text-slate-500">Loading meals...</p>
                    </div>
                  ) : getMealsForDate(selectedDate).length > 0 ? (
                    getMealsForDate(selectedDate).map((meal, idx) => (
                      <MealCard key={idx} meal={meal} />
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-500">
                      <ChefHat className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                      <p>No meals planned for this day</p>
                      <div className="flex justify-center space-x-2 mt-4">
                        <Button variant="outline" onClick={() => setIsCreateMealOpen(true)}>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Meal
                        </Button>
                        <Button variant="outline" onClick={() => setShowMealGenerator(true)}>
                          <Sparkles className="h-4 w-4 mr-2" />
                          Generate with AI
                        </Button>
                      </div>
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        ) : (
          /* List View */
          <div className="space-y-6">
            {getWeekMeals().map((day, idx) => {
              const filteredDayMeals = day.meals.filter(meal => 
                selectedCategory === "all" || meal.mealType === selectedCategory
              );

              return (
                <Card key={idx}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">
                        {format(day.date, "EEEE, MMMM d")}
                      </CardTitle>
                      {filteredDayMeals.length > 0 && (
                        <Badge variant="outline">
                          {filteredDayMeals.length} meal{filteredDayMeals.length > 1 ? 's' : ''}
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {filteredDayMeals.length > 0 ? (
                      filteredDayMeals.map((meal, mealIdx) => (
                        <MealCard key={mealIdx} meal={meal} />
                      ))
                    ) : (
                      <p className="text-slate-500 text-center py-4">
                        {selectedCategory === "all" ? "No meals planned" : `No ${selectedCategory} meals planned`}
                      </p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}