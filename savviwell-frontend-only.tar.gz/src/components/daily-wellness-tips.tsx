
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { 
  Heart, 
  Lightbulb, 
  Sparkles, 
  Calendar,
  Download,
  RefreshCw,
  Clock,
  Target,
  Leaf,
  Droplets,
  Sun,
  Moon,
  Activity,
  Brain
} from "lucide-react";
import { format } from "date-fns";

interface WellnessTip {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  difficulty: "easy" | "moderate" | "challenging";
  estimatedTime: string;
  benefits: string[];
  createdAt: string;
}

interface DailyWellnessData {
  date: string;
  tips: WellnessTip[];
  focusArea: string;
  personalizedMessage: string;
  completedTips: string[];
  streakCount: number;
}

const categoryIcons: { [key: string]: any } = {
  nutrition: Leaf,
  hydration: Droplets,
  exercise: Activity,
  sleep: Moon,
  mindfulness: Brain,
  energy: Sun,
  general: Heart
};

const categoryColors: { [key: string]: string } = {
  nutrition: "emerald",
  hydration: "blue",
  exercise: "orange",
  sleep: "purple",
  mindfulness: "indigo",
  energy: "yellow",
  general: "pink"
};

export function DailyWellnessTips() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [completedTips, setCompletedTips] = useState<string[]>([]);
  const queryClient = useQueryClient();

  const { data: dailyWellness, isLoading } = useQuery({
    queryKey: ["/api/wellness/daily", format(selectedDate, "yyyy-MM-dd")],
    refetchOnWindowFocus: false,
    staleTime: 1000 * 60 * 30, // 30 minutes
  });

  const { data: userStats } = useQuery({
    queryKey: ["/api/wellness/stats"],
  });

  const markTipCompletedMutation = useMutation({
    mutationFn: async ({ tipId, completed }: { tipId: string; completed: boolean }) => {
      const response = await apiRequest("POST", "/api/wellness/complete-tip", {
        tipId,
        date: format(selectedDate, "yyyy-MM-dd"),
        completed
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wellness/daily"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wellness/stats"] });
    }
  });

  const generateNewTipsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/wellness/generate-daily", {
        date: format(selectedDate, "yyyy-MM-dd"),
        preferences: {
          focusAreas: ["nutrition", "exercise", "mindfulness"],
          difficulty: "moderate",
          timeAvailable: "15-30 minutes"
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wellness/daily"] });
    }
  });

  const saveTipToLibraryMutation = useMutation({
    mutationFn: async (tip: WellnessTip) => {
      const response = await apiRequest("POST", "/api/wellness-tips", {
        title: tip.title,
        content: tip.content,
        category: tip.category,
        tags: tip.tags,
        isUserCreated: false,
        aiGenerated: true,
        difficulty: tip.difficulty,
        estimatedTime: tip.estimatedTime,
        benefits: tip.benefits
      });
      return response.json();
    },
    onSuccess: () => {
      console.log("Tip saved to wellness library");
    }
  });

  const handleTipComplete = (tipId: string) => {
    const isCompleted = completedTips.includes(tipId);
    if (isCompleted) {
      setCompletedTips(prev => prev.filter(id => id !== tipId));
    } else {
      setCompletedTips(prev => [...prev, tipId]);
    }
    markTipCompletedMutation.mutate({ tipId, completed: !isCompleted });
  };

  const TipCard = ({ tip }: { tip: WellnessTip }) => {
    const CategoryIcon = categoryIcons[tip.category] || Heart;
    const isCompleted = completedTips.includes(tip.id);
    const colorClass = categoryColors[tip.category] || "pink";

    return (
      <Card className={`mb-4 transition-all duration-200 ${isCompleted ? 'bg-green-50 border-green-200' : 'hover:shadow-md'}`}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center space-x-2">
              <CategoryIcon className={`h-5 w-5 text-${colorClass}-600`} />
              <h3 className="font-semibold text-slate-800">{tip.title}</h3>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className={`bg-${colorClass}-50 text-${colorClass}-700`}>
                {tip.category}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {tip.estimatedTime}
              </Badge>
            </div>
          </div>

          <p className="text-slate-600 mb-3 leading-relaxed">{tip.content}</p>

          {tip.benefits && tip.benefits.length > 0 && (
            <div className="mb-3">
              <h4 className="text-sm font-medium text-slate-700 mb-1">Benefits:</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                {tip.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-center">
                    <div className={`w-2 h-2 bg-${colorClass}-500 rounded-full mr-2`} />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant={isCompleted ? "default" : "outline"}
                onClick={() => handleTipComplete(tip.id)}
                className={isCompleted ? "bg-green-600 hover:bg-green-700" : ""}
              >
                {isCompleted ? "✓ Completed" : "Mark Complete"}
              </Button>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline">
                    <Target className="h-4 w-4 mr-1" />
                    Details
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="flex items-center space-x-2">
                      <CategoryIcon className={`h-5 w-5 text-${colorClass}-600`} />
                      <span>{tip.title}</span>
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-slate-700">{tip.content}</p>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-slate-800 mb-1">Difficulty</h4>
                        <Badge variant={tip.difficulty === "easy" ? "default" : tip.difficulty === "moderate" ? "secondary" : "destructive"}>
                          {tip.difficulty}
                        </Badge>
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-800 mb-1">Time Needed</h4>
                        <div className="flex items-center text-slate-600">
                          <Clock className="h-4 w-4 mr-1" />
                          {tip.estimatedTime}
                        </div>
                      </div>
                    </div>

                    {tip.tags && tip.tags.length > 0 && (
                      <div>
                        <h4 className="font-medium text-slate-800 mb-2">Tags</h4>
                        <div className="flex flex-wrap gap-1">
                          {tip.tags.map((tag, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <Button
              size="sm"
              variant="ghost"
              onClick={() => saveTipToLibraryMutation.mutate(tip)}
              className="text-blue-600 hover:text-blue-700"
            >
              <Download className="h-4 w-4 mr-1" />
              Save
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-6 w-6 animate-spin text-blue-500 mr-2" />
        <span className="text-slate-600">Loading wellness tips...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-50 to-emerald-50 border-none">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2 text-slate-800">
                <Sparkles className="h-6 w-6 text-emerald-600" />
                <span>Daily Wellness Tips</span>
              </CardTitle>
              <p className="text-slate-600 mt-1">
                {format(selectedDate, "EEEE, MMMM d, yyyy")}
              </p>
            </div>
            <div className="text-right">
              {userStats && (
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-emerald-600">
                    {userStats.currentStreak || 0}
                  </div>
                  <div className="text-xs text-slate-500">day streak</div>
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {dailyWellness?.personalizedMessage && (
            <div className="bg-white/60 rounded-lg p-3 border border-white/40">
              <p className="text-slate-700 font-medium">
                {dailyWellness.personalizedMessage}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Focus Area */}
      {dailyWellness?.focusArea && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Target className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold text-slate-800">Today's Focus</h3>
            </div>
            <p className="text-slate-600 capitalize">{dailyWellness.focusArea}</p>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex space-x-2">
        <Button
          onClick={() => generateNewTipsMutation.mutate()}
          disabled={generateNewTipsMutation.isPending}
          className="flex-1"
        >
          {generateNewTipsMutation.isPending ? (
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Sparkles className="h-4 w-4 mr-2" />
          )}
          Generate New Tips
        </Button>
        
        <Button
          variant="outline"
          onClick={() => setSelectedDate(new Date())}
          disabled={format(selectedDate, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd")}
        >
          <Calendar className="h-4 w-4 mr-2" />
          Today
        </Button>
      </div>

      {/* Tips List */}
      <div>
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          Your Wellness Tips ({dailyWellness?.tips?.length || 0})
        </h3>
        
        <ScrollArea className="h-96">
          {dailyWellness?.tips && dailyWellness.tips.length > 0 ? (
            dailyWellness.tips.map((tip: WellnessTip) => (
              <TipCard key={tip.id} tip={tip} />
            ))
          ) : (
            <Card className="text-center p-8">
              <Heart className="h-12 w-12 mx-auto text-slate-300 mb-4" />
              <h3 className="font-medium text-slate-700 mb-2">No wellness tips yet</h3>
              <p className="text-slate-500 mb-4">
                Generate personalized wellness tips for today to get started!
              </p>
              <Button onClick={() => generateNewTipsMutation.mutate()}>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Tips
              </Button>
            </Card>
          )}
        </ScrollArea>
      </div>

      {/* Progress Summary */}
      {dailyWellness?.tips && dailyWellness.tips.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-700 font-medium">Today's Progress</span>
              <span className="text-emerald-600 font-bold">
                {completedTips.length} / {dailyWellness.tips.length} completed
              </span>
            </div>
            <div className="mt-2 bg-slate-200 rounded-full h-2">
              <div 
                className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                style={{ 
                  width: `${dailyWellness.tips.length > 0 ? (completedTips.length / dailyWellness.tips.length) * 100 : 0}%` 
                }}
              />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
