import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function generateMealPlan(requirements: {
  days: number;
  caloriesPerDay: number;
  dietaryRestrictions: string[];
  healthGoals: string[];
}): Promise<any> {
  const prompt = `Create a ${requirements.days}-day meal plan with the following requirements:
- Daily calorie target: ${requirements.caloriesPerDay} calories
- Dietary restrictions: ${requirements.dietaryRestrictions.join(", ") || "None"}
- Health goals: ${requirements.healthGoals.join(", ") || "General health"}

Format the response as JSON with this structure:
{
  "title": "Week Meal Plan",
  "totalCalories": number,
  "meals": [
    {
      "day": "Monday",
      "breakfast": { "name": "meal name", "calories": number },
      "lunch": { "name": "meal name", "calories": number },
      "dinner": { "name": "meal name", "calories": number },
      "snacks": [{ "name": "snack name", "calories": number }],
      "totalCalories": number
    }
  ]
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a nutrition expert. Create detailed, healthy meal plans in JSON format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error generating meal plan:", error);
    throw new Error("Failed to generate meal plan");
  }
}

export async function findRestaurants(criteria: {
  cuisine?: string;
  dietary?: string[];
  location?: string;
  priceRange?: string;
}): Promise<any> {
  const prompt = `Find restaurant recommendations based on:
- Cuisine: ${criteria.cuisine || "Any"}
- Dietary requirements: ${criteria.dietary?.join(", ") || "None"}
- Location: ${criteria.location || "Local area"}
- Price range: ${criteria.priceRange || "Mid-range"}

Format the response as JSON with this structure:
{
  "restaurants": [
    {
      "name": "Restaurant Name",
      "cuisine": "cuisine type",
      "address": "address",
      "priceRange": "$$ or $$$ etc",
      "specialties": ["dish1", "dish2"],
      "dietaryOptions": ["vegetarian", "gluten-free"],
      "rating": 4.5,
      "estimatedWaitTime": "30-45 minutes"
    }
  ]
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a restaurant expert. Provide realistic restaurant recommendations in JSON format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error finding restaurants:", error);
    throw new Error("Failed to find restaurants");
  }
}
