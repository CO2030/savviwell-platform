import { useState, useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";

export function useTextToSpeech() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported] = useState(true); // Gemini TTS is always supported
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null);

  const speak = useCallback(async (text: string, options?: {
    voice?: string;
    style?: string;
    rate?: number;
  }) => {
    try {
      // Stop any currently playing audio
      if (currentAudio) {
        currentAudio.pause();
        currentAudio.src = '';
        setCurrentAudio(null);
      }

      setIsSpeaking(true);

      // Clean text: remove emojis and special characters
      const cleanText = text
        .replace(/[\uD83C-\uDBFF\uDC00-\uDFFF]/g, '') // surrogate pairs (emojis)
        .replace(/[\u2600-\u26FF\u2700-\u27BF]/g, '') // misc symbols and dingbats
        .replace(/[^\w\s.,!?;:'-]/g, '')
        .trim();

      if (!cleanText) {
        setIsSpeaking(false);
        return;
      }

      // Use Gemini TTS with enhanced voice
      const voiceName = options?.voice || 'Aoede'; // Default to Aoede (muse of song)
      const stylePrompt = options?.style || 'Say this in a warm, friendly, and natural tone';
      
      console.log(`🎤 Attempting TTS with voice: ${voiceName}, text: "${cleanText}"`);
      
      const response = await apiRequest("POST", "/api/text-to-speech", {
        text: cleanText,
        voiceName: voiceName,
        stylePrompt: stylePrompt
      });

      if (!response.ok) {
        throw new Error(`TTS request failed with status: ${response.status}`);
      }

      const result = await response.json();
      
      if (result.success && result.audioData) {
        console.log(`✅ Playing Gemini TTS audio with ${result.voiceUsed} voice`);
        
        try {
          // Convert base64 audio to blob and play
          const binaryString = atob(result.audioData);
          const bytes = new Uint8Array(binaryString.length);
          
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          
          // Use the MIME type provided by Gemini
          let mimeType = result.mimeType || 'audio/wav';
          
          // Ensure we have a supported audio format
          if (!mimeType.startsWith('audio/')) {
            mimeType = 'audio/wav';
          }
          
          const blob = new Blob([bytes], { type: mimeType });
          const audioUrl = URL.createObjectURL(blob);
          
          console.log(`🎵 Created Gemini audio blob: ${mimeType}, size: ${blob.size} bytes`);
          
          const audio = new Audio();
          setCurrentAudio(audio);
          
          // Set up event handlers before setting src
          audio.oncanplaythrough = () => {
            console.log('✅ Gemini audio can play through');
            audio.play().catch(err => {
              console.error('Gemini audio play error:', err);
              throw new Error('Gemini audio play failed');
            });
          };
          
          audio.onloadeddata = () => {
            console.log('✅ Gemini audio data loaded successfully');
          };
          
          audio.src = audioUrl;
      
          audio.onended = () => {
            setIsSpeaking(false);
            URL.revokeObjectURL(audioUrl);
            setCurrentAudio(null);
          };
          
          audio.onerror = (e) => {
            console.error('Audio playback failed:', e);
            URL.revokeObjectURL(audioUrl);
            setCurrentAudio(null);
            throw new Error('Audio playback failed');
          };
            
        } catch (audioError) {
          console.error('Audio processing failed:', audioError);
          throw audioError;
        }
      } else if (result.fallbackToBrowser) {
        console.log('🔄 Server requested browser TTS fallback');
        // Use enhanced text if available, otherwise use original
        const textToSpeak = result.enhancedText || cleanText;
        
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.rate = options?.rate || 0.9;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        // Try to use a better voice if available
        const voices = speechSynthesis.getVoices();
        const preferredVoice = voices.find(voice => 
          voice.name.includes('Microsoft') || 
          voice.name.includes('Google') ||
          voice.name.includes('Alex') ||
          voice.name.includes('Samantha')
        );
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
        
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        
        speechSynthesis.speak(utterance);
        return; // Exit here, don't throw error
      } else {
        throw new Error('No audio data received from TTS service');
      }
    } catch (error: any) {
      console.log('🔄 Using browser TTS fallback:', error.message);
      
      // Clean text for fallback as well
      const cleanText = text
        .replace(/[\uD83C-\uDBFF\uDC00-\uDFFF]/g, '') // surrogate pairs (emojis)
        .replace(/[\u2600-\u26FF\u2700-\u27BF]/g, '') // misc symbols and dingbats
        .replace(/[^\w\s.,!?;:'-]/g, '')
        .trim();
      
      if (!cleanText) {
        setIsSpeaking(false);
        return;
      }
      
      // Fallback to browser TTS
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = options?.rate || 0.9;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      
      speechSynthesis.speak(utterance);
    }
  }, [currentAudio]);

  const stop = useCallback(() => {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.src = '';
      setCurrentAudio(null);
    }
    
    // Also cancel browser TTS if running
    speechSynthesis.cancel();
    setIsSpeaking(false);
  }, [currentAudio]);

  const getVoices = useCallback(() => {
    // Return available Gemini TTS voices
    return [
      { name: 'Aoede', description: 'Warm, melodious voice (Gemini default)' },
      { name: 'Callirrhoe', description: 'Natural, expressive voice (Gemini premium)' },
      { name: 'Kore', description: 'Clear, articulate, professional (Gemini)' },
      { name: 'Puck', description: 'Playful, energetic, youthful (Gemini)' },
      { name: 'Charon', description: 'Deep, authoritative, calm (Gemini)' },
      { name: 'Fenrir', description: 'Strong, confident, powerful (Gemini)' }
    ];
  }, []);

  return {
    speak,
    stop,
    isSpeaking,
    isSupported,
    getVoices,
  };
}
