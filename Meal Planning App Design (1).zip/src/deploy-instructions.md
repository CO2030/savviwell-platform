# Deployment Instructions for Savviwell Platform

## Quick Deployment Commands

Since you already have GitHub Pages set up, here are the steps to deploy your updated app:

### 1. Install Dependencies
```bash
npm install
```

### 2. Test Locally (Optional)
```bash
npm start
# App will open at http://localhost:3000
```

### 3. Build for Production
```bash
npm run build
# This creates a 'dist' folder with your built app
```

### 4. Deploy to GitHub Pages
```bash
# Add all changes
git add .

# Commit changes
git commit -m "Configure GitHub Pages deployment and update app"

# Push to main branch (triggers auto-deployment)
git push origin main
```

## What Happens Next

1. **GitHub Actions** will automatically trigger when you push to main
2. The workflow will:
   - Install dependencies (`npm ci`)
   - Build your app (`npm run build`)
   - Deploy the `dist` folder to GitHub Pages
3. Your app will be available at: **https://co2030.github.io/savviwell-platform/**

## Configuration Updates Made

✅ **Vite Config**: Set base path to `/savviwell-platform/`
✅ **Package.json**: Updated homepage and repository URLs
✅ **GitHub Workflow**: Created proper deployment workflow
✅ **HTML Meta Tags**: Updated social sharing URLs
✅ **README**: Updated all repository references

## Troubleshooting

### If deployment fails:
1. Check the **Actions** tab in your GitHub repository
2. Look for any error messages in the workflow logs
3. Common issues:
   - Node.js version mismatch (workflow uses Node 18)
   - Missing dependencies
   - Build errors

### If the app loads but assets are missing:
- This usually means the base path is incorrect
- Double-check that `vite.config.ts` has the correct repository name

### Manual deployment (backup option):
```bash
npm run build
npm run deploy
```

## Next Steps After Deployment

Once your app is live, you can:
1. **Share the URL**: https://co2030.github.io/savviwell-platform/
2. **Set up custom domain** (optional): Configure in GitHub Pages settings
3. **Monitor usage**: Check GitHub Pages analytics
4. **Continuous updates**: Any push to main will auto-deploy

## Repository Structure for GitHub Pages

```
├── .github/workflows/deploy.yml  # Auto-deployment workflow
├── dist/                         # Built files (auto-generated)
├── src/                         # Source files
├── package.json                 # Dependencies & scripts
├── vite.config.ts              # Build configuration
└── index.html                  # Entry point
```

Your Savvi meal planning app is now ready for GitHub Pages deployment! 🚀