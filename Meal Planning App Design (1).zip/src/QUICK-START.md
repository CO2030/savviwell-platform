# 🚀 Quick Start - Get Savvi Running in 5 Minutes

## Prerequisites Check ✅

Before starting, make sure you have:
- [ ] **Node.js 18+** installed ([Download](https://nodejs.org/))
- [ ] **Git** installed ([Download](https://git-scm.com/))
- [ ] Your code files ready (from Figma Make)

## 5-Minute Setup

### 1. Open Terminal 💻
- **Windows**: Win + R, type `cmd`, press Enter
- **Mac**: Cmd + Space, type `terminal`, press Enter
- **Linux**: Ctrl + Alt + T

### 2. Navigate to Your Project 📁
```bash
cd Desktop/savviwell-platform
# (or wherever you saved your project files)
```

### 3. Install Everything 📦
```bash
npm install
```
*This downloads React, Tailwind, and all dependencies*

### 4. Start Your App 🎉
```bash
npm start
```
*Your app opens at http://localhost:3000*

### 5. Deploy to GitHub 🌐
```bash
git add .
git commit -m "Deploy Savvi app"
git push origin main
```
*Live in 3 minutes at https://co2030.github.io/savviwell-platform/*

## That's It! 🎯

Your Savvi meal planning app is now:
- ✅ Running locally for development
- ✅ Deployed live on the internet
- ✅ Auto-updating when you push changes

## Common Issues & Quick Fixes

**"npm not found"**
```bash
# Install Node.js first, then retry
```

**"Permission denied"**
```bash
sudo npm install  # Mac/Linux
# Or run as administrator on Windows
```

**"Git not found"**
```bash
# Install Git, then run:
git init
git remote add origin https://github.com/co2030/savviwell-platform.git
```

## Next Steps

1. **Test your live app**: https://co2030.github.io/savviwell-platform/
2. **Share with friends**: Get feedback on your meal planning app
3. **Make improvements**: Any changes you push will auto-deploy

Your AI-powered meal planning app is ready to help people eat healthier! 🥗✨