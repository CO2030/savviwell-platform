# Savvi - AI-Powered Meal Planning App

A comprehensive mobile-first meal planning application built with React and Tailwind CSS, featuring AI assistance, recipe management, grocery lists, and nutritional tracking.

## 🌟 Features

- 📅 **Calendar-based Meal Planning** - Schedule meals for specific dates with visual indicators
- 🤖 **AI Assistant** - Voice and text-based meal planning help with smart suggestions
- 🍳 **Recipe Management** - Search, filter, and view detailed recipes with nutrition info
- 🛒 **Smart Grocery Lists** - Auto-generated shopping lists from meal plans with categories
- 📊 **Nutrition Tracking** - Daily goals and progress monitoring with visual charts
- 🎯 **Dietary Preferences** - Customize for restrictions, allergies, and cuisine preferences
- 🎙️ **Voice Interface** - Floating microphone button for hands-free interaction
- 📱 **Mobile-First Design** - Optimized for mobile with responsive layouts

## 🚀 Live Demo

Visit the live app: [https://co2030.github.io/savviwell-platform](https://co2030.github.io/savviwell-platform)

## 🛠️ Tech Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS v4 with custom design system
- **Icons**: Lucide React (comprehensive icon library)
- **UI Components**: Custom components built on Radix UI primitives
- **Build Tool**: Vite for fast development and optimized builds
- **Deployment**: GitHub Pages with automated workflows

## 🏃‍♂️ Getting Started

### Prerequisites
- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/co2030/savviwell-platform.git
   cd savviwell-platform
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm start
   ```

4. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Building for Production

```bash
npm run build
```

The build artifacts will be stored in the `dist/` directory.

### Deploying to GitHub Pages

```bash
npm run deploy
```

This will build the app and deploy it to GitHub Pages automatically.

## 📱 App Screens

### Main Navigation
- **Calendar View** - Primary screen showing monthly view with meal indicators
- **AI Assistant** - Voice and text interaction with organized action buttons
- **Meal Plans** - Browse and manage your meal collection
- **Grocery Lists** - Categorized shopping lists with progress tracking
- **Recipe Search** - Filter by cuisine, diet, and cooking time

### Key Features
- **Floating Microphone** - Available on Calendar, Grocery, and Meal screens
- **AI Popup Overlay** - Quick access to AI assistant from any screen
- **Responsive Design** - Works seamlessly on mobile and desktop
- **Smart Navigation** - Context-aware navigation between related screens

## 🎨 Design System

The app uses a custom design system with:
- **Base font size**: 14px for optimal mobile readability
- **Color palette**: Custom CSS variables for consistent theming
- **Typography**: Hierarchical text sizing with proper line heights
- **Components**: Reusable UI components with consistent styling
- **Dark mode**: Full support for dark and light themes

## 📦 Project Structure

```
├── App.tsx                 # Main application component
├── src/
│   └── main.tsx           # Application entry point
├── components/
│   ├── ui/                # Reusable UI components (ShadCN/UI)
│   └── figma/             # Custom components and utilities
├── styles/
│   └── globals.css        # Global CSS with Tailwind configuration
├── guidelines/
│   └── Guidelines.md      # Development guidelines and standards
└── .github/
    └── workflows/         # GitHub Actions for deployment
```

## 🔧 Configuration Files

- `vite.config.ts` - Vite build configuration
- `tailwind.config.js` - Tailwind CSS customization
- `tsconfig.json` - TypeScript configuration
- `package.json` - Dependencies and scripts

## 🚀 Deployment

The app is automatically deployed to GitHub Pages using GitHub Actions:

1. **Push to main branch** triggers the deployment workflow
2. **Build process** runs `npm run build`
3. **Deploy** uploads the `dist/` folder to GitHub Pages
4. **Live site** is available at your GitHub Pages URL

### Manual Deployment

You can also deploy manually using:
```bash
npm run predeploy  # Builds the app
npm run deploy     # Deploys to GitHub Pages
```

## 🎯 Usage Tips

### Voice Commands
- "Add salmon to grocery list"
- "What's for dinner tomorrow?"
- "Show me vegetarian recipes"
- "Plan meals for this week"

### Navigation
- **Tap dates** with meal indicators to view detailed meal plans
- **Use floating mic** button for quick AI access
- **Swipe through** action buttons in AI assistant
- **Filter recipes** by cuisine, diet, and cooking time

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**Co2030**
- GitHub: [@co2030](https://github.com/co2030)
- Project: [Savviwell Platform](https://github.com/co2030/savviwell-platform)

---

<div align="center">
  <p>Made with ❤️ for healthy meal planning</p>
  <p>🥗 Savvi - Your AI Meal Planning Assistant</p>
</div>