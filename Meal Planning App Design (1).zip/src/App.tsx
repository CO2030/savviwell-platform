import React, { useState } from 'react';
import { Calendar, Home, Mic, FileText, Utensils, ChevronLeft, MoreHorizontal, User, Clock, MapPin, Heart, Share2, ShoppingCart, Plus, Minus, CheckSquare, Square, Timer, Users, Search, Filter, Star, Settings, Target, TrendingUp, ChevronRight, Send, Scan, Truck } from 'lucide-react';
import { Button } from './components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from './components/ui/avatar';
import { Card, CardContent } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { Separator } from './components/ui/separator';
import { Input } from './components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Switch } from './components/ui/switch';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('calendar');
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [selectedDate, setSelectedDate] = useState('2025-01-02');
  const [isRecording, setIsRecording] = useState(false);
  const [isAIPopupOpen, setIsAIPopupOpen] = useState(false);
  const [aiTextInput, setAiTextInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('all');
  const [selectedDiet, setSelectedDiet] = useState('all');
  const [maxCookTime, setMaxCookTime] = useState('60');
  
  const [groceryList, setGroceryList] = useState([
    { id: 1, name: 'Fresh Spinach', category: 'Produce', checked: false, quantity: '2 cups' },
    { id: 2, name: 'Cherry Tomatoes', category: 'Produce', checked: true, quantity: '1 lb' },
    { id: 3, name: 'Quinoa', category: 'Grains', checked: false, quantity: '1 cup' },
    { id: 4, name: 'Chicken Breast', category: 'Meat', checked: false, quantity: '2 lbs' },
    { id: 5, name: 'Greek Yogurt', category: 'Dairy', checked: true, quantity: '1 container' },
    { id: 6, name: 'Avocado', category: 'Produce', checked: false, quantity: '2 pieces' },
  ]);

  const [mealSchedule, setMealSchedule] = useState({
    '2025-01-01': { 
      breakfast: { recipe: 'Fruit Smoothie Bowl', calories: 280 }, 
      lunch: { recipe: 'Vibrant Veggie Bowl', calories: 350 }, 
      dinner: { recipe: 'Mediterranean Pasta', calories: 420 } 
    },
    '2025-01-02': { 
      breakfast: { recipe: 'Oatmeal with Berries', calories: 300 }, 
      lunch: { recipe: 'Chicken Salad Sandwich', calories: 340 }, 
      dinner: { recipe: 'Salmon with Roasted Vegetables', calories: 500 } 
    },
    '2025-01-03': { 
      breakfast: { recipe: 'Fruit Smoothie Bowl', calories: 280 }, 
      lunch: { recipe: 'Asian Stir Fry', calories: 320 }, 
      dinner: { recipe: 'Grilled Chicken Plate', calories: 450 } 
    },
    '2025-01-04': { 
      breakfast: { recipe: 'Avocado Toast', calories: 250 }, 
      lunch: { recipe: 'Mediterranean Pasta', calories: 420 }, 
      dinner: { recipe: 'Vibrant Veggie Bowl', calories: 350 } 
    },
    '2025-01-05': { 
      breakfast: { recipe: 'Greek Yogurt Parfait', calories: 280 }, 
      lunch: { recipe: 'Grilled Chicken Plate', calories: 450 }, 
      dinner: { recipe: 'Asian Stir Fry', calories: 320 } 
    },
    '2025-01-06': { 
      breakfast: { recipe: 'Pancakes with Syrup', calories: 380 }, 
      lunch: { recipe: 'Salmon Salad', calories: 350 }, 
      dinner: { recipe: 'Mediterranean Pasta', calories: 420 } 
    },
    '2025-01-07': { 
      breakfast: { recipe: 'Smoothie Bowl', calories: 290 }, 
      lunch: { recipe: 'Chicken Wrap', calories: 380 }, 
      dinner: { recipe: 'Grilled Fish', calories: 420 } 
    }
  });

  const [nutritionGoals, setNutritionGoals] = useState({
    calories: 2000,
    protein: 150,
    carbs: 250,
    fat: 65,
    fiber: 25
  });

  const [nutritionProgress, setNutritionProgress] = useState({
    calories: 1680,
    protein: 120,
    carbs: 180,
    fat: 58,
    fiber: 18
  });

  const [userPreferences, setUserPreferences] = useState({
    dietaryRestrictions: ['vegetarian'],
    allergies: ['nuts'],
    cuisinePreferences: ['mediterranean', 'asian'],
    mealPrepTime: 30,
    servingSize: 2
  });

  const allRecipes = [
    {
      id: 1,
      title: "Vibrant Veggie Bowl",
      image: "https://images.unsplash.com/photo-1744116432654-574391dbe3ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwc2FsYWQlMjBib3dsJTIwY29sb3JmdWwlMjB2ZWdldGFibGVzfGVufDF8fHx8MTc1NjUyNjA4MXww&ixlib=rb-4.1.0&q=80&w=400",
      cookTime: 15,
      servings: 2,
      calories: 350,
      protein: 12,
      carbs: 45,
      fat: 15,
      cuisine: 'mediterranean',
      diet: 'vegetarian',
      rating: 4.8,
      description: "A nutritious and colorful bowl packed with fresh vegetables, quinoa, and a tahini dressing.",
      ingredients: [
        "2 cups mixed greens",
        "1 cup cooked quinoa",
        "1/2 cup cherry tomatoes",
        "1/2 cucumber, diced",
        "1/4 red onion, sliced",
        "2 tbsp tahini",
        "1 tbsp lemon juice",
        "1 tbsp olive oil"
      ],
      instructions: [
        "Cook quinoa according to package instructions and let cool.",
        "Wash and prepare all vegetables.",
        "In a small bowl, whisk together tahini, lemon juice, and olive oil.",
        "Arrange greens in bowls, top with quinoa and vegetables.",
        "Drizzle with tahini dressing and serve immediately."
      ]
    },
    {
      id: 2,
      title: "Grilled Chicken Plate",
      image: "https://images.unsplash.com/photo-1749880183062-ffbf14738723?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwY2hpY2tlbiUyMHF1aW5vYSUyMHBsYXRlfGVufDF8fHx8MTc1NjUyNjA4MXww&ixlib=rb-4.1.0&q=80&w=400",
      cookTime: 25,
      servings: 4,
      calories: 450,
      protein: 35,
      carbs: 32,
      fat: 18,
      cuisine: 'american',
      diet: 'high-protein',
      rating: 4.6,
      description: "Perfectly grilled chicken breast served with fluffy quinoa and roasted vegetables.",
      ingredients: [
        "4 chicken breasts",
        "1 cup quinoa",
        "2 cups mixed vegetables",
        "3 tbsp olive oil",
        "2 tsp garlic powder",
        "1 tsp paprika",
        "Salt and pepper to taste"
      ],
      instructions: [
        "Season chicken breasts with garlic powder, paprika, salt, and pepper.",
        "Heat grill to medium-high heat.",
        "Cook quinoa according to package instructions.",
        "Grill chicken for 6-7 minutes per side until cooked through.",
        "Roast vegetables with olive oil at 400°F for 20 minutes.",
        "Serve chicken over quinoa with roasted vegetables."
      ]
    },
    {
      id: 3,
      title: "Fruit Smoothie Bowl",
      image: "https://images.unsplash.com/photo-1621797350487-c8996f886ab1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcnVpdCUyMHNtb290aGllJTIwYm93bCUyMGJlcnJpZXN8ZW58MXx8fHwxNzU2NTI2MDgxfDA&ixlib=rb-4.1.0&q=80&w=400",
      cookTime: 10,
      servings: 1,
      calories: 280,
      protein: 8,
      carbs: 55,
      fat: 6,
      cuisine: 'american',
      diet: 'vegan',
      rating: 4.9,
      description: "A refreshing smoothie bowl topped with fresh berries, granola, and coconut flakes.",
      ingredients: [
        "1 frozen banana",
        "1/2 cup frozen berries",
        "1/2 cup almond milk",
        "1 tbsp honey",
        "1/4 cup granola",
        "2 tbsp coconut flakes",
        "Fresh berries for topping"
      ],
      instructions: [
        "Add frozen banana, berries, almond milk, and honey to blender.",
        "Blend until smooth and thick.",
        "Pour into a bowl.",
        "Top with granola, coconut flakes, and fresh berries.",
        "Serve immediately while cold."
      ]
    },
    {
      id: 4,
      title: "Mediterranean Pasta",
      image: "https://images.unsplash.com/photo-1667473775795-41f69ae72c44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGVycmFuZWFuJTIwZm9vZCUyMHBhc3RhfGVufDF8fHx8MTc1NjUyNjQ0Mnww&ixlib=rb-4.1.0&q=80&w=400",
      cookTime: 20,
      servings: 3,
      calories: 420,
      protein: 18,
      carbs: 52,
      fat: 16,
      cuisine: 'mediterranean',
      diet: 'vegetarian',
      rating: 4.7,
      description: "Classic Mediterranean pasta with fresh tomatoes, olives, and feta cheese.",
      ingredients: [
        "300g pasta",
        "2 cups cherry tomatoes",
        "1/2 cup kalamata olives",
        "150g feta cheese",
        "3 tbsp olive oil",
        "2 cloves garlic",
        "Fresh basil leaves"
      ],
      instructions: [
        "Cook pasta according to package instructions.",
        "Heat olive oil in a large pan.",
        "Add garlic and cook for 1 minute.",
        "Add cherry tomatoes and cook until soft.",
        "Add cooked pasta, olives, and feta.",
        "Garnish with fresh basil and serve."
      ]
    },
    {
      id: 5,
      title: "Asian Stir Fry",
      image: "https://images.unsplash.com/photo-1614955177711-2540ad25432b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMHN0aXIlMjBmcnklMjB2ZWdldGFibGVzfGVufDF8fHx8MTc1NjUyNjQ0M3ww&ixlib=rb-4.1.0&q=80&w=400",
      cookTime: 18,
      servings: 2,
      calories: 320,
      protein: 15,
      carbs: 28,
      fat: 18,
      cuisine: 'asian',
      diet: 'vegan',
      rating: 4.5,
      description: "Colorful vegetable stir fry with aromatic Asian flavors and tofu.",
      ingredients: [
        "200g firm tofu",
        "2 cups mixed vegetables",
        "2 tbsp soy sauce",
        "1 tbsp sesame oil",
        "1 tsp ginger",
        "2 cloves garlic",
        "1 tbsp vegetable oil"
      ],
      instructions: [
        "Cut tofu into cubes and vegetables into bite-sized pieces.",
        "Heat vegetable oil in a wok or large pan.",
        "Add garlic and ginger, stir for 30 seconds.",
        "Add tofu and cook until golden.",
        "Add vegetables and stir fry for 3-4 minutes.",
        "Add soy sauce and sesame oil, toss to combine."
      ]
    }
  ];

  const currentDate = new Date();
  const monthName = currentDate.toLocaleDateString('en-US', { month: 'long' });

  // Helper function to get recipe details by title
  const getRecipeByTitle = (title) => {
    return allRecipes.find(recipe => recipe.title === title) || {
      title,
      image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGxhdGV8ZW58MXx8fHwxNzU2NTI2ODAwfDA&ixlib=rb-4.1.0&q=80&w=400",
      cookTime: 15,
      servings: 1,
      calories: 300,
      cuisine: 'american',
      diet: 'balanced',
      rating: 4.5
    };
  };

  // Get days of week for navigation
  const getDaysOfWeek = () => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const dates = [];
    for (let i = 1; i <= 7; i++) {
      dates.push({
        day: days[i - 1],
        date: `2025-01-${i.toString().padStart(2, '0')}`,
        dayNumber: i
      });
    }
    return dates;
  };

  const filterRecipes = () => {
    return allRecipes.filter(recipe => {
      const matchesSearch = recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           recipe.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCuisine = selectedCuisine === 'all' || recipe.cuisine === selectedCuisine;
      const matchesDiet = selectedDiet === 'all' || recipe.diet === selectedDiet;
      const matchesTime = recipe.cookTime <= parseInt(maxCookTime);
      
      return matchesSearch && matchesCuisine && matchesDiet && matchesTime;
    });
  };

  const DailyMealPlanScreen = () => {
    const daysOfWeek = getDaysOfWeek();
    const currentMeals = mealSchedule[selectedDate] || { breakfast: null, lunch: null, dinner: null };

    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm" 
              className="rounded-full w-10 h-10 p-0"
              onClick={() => setCurrentScreen('calendar')}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">Meal Plan</h1>
          </div>
          <Button variant="ghost" size="sm" className="rounded-full w-10 h-10 p-0">
            <MoreHorizontal className="h-5 w-5" />
          </Button>
        </div>

        {/* Days Navigation */}
        <div className="bg-white border-b border-gray-100">
          <div className="flex overflow-x-auto px-4 py-3">
            {daysOfWeek.map((day, index) => (
              <Button
                key={day.date}
                variant="ghost"
                className={`flex-shrink-0 flex flex-col items-center min-w-[60px] mx-1 ${
                  selectedDate === day.date 
                    ? 'bg-blue-50 text-blue-600 border border-blue-200' 
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
                onClick={() => setSelectedDate(day.date)}
              >
                <span className="text-xs font-medium">{day.day}</span>
                <span className="text-lg font-medium mt-1">{day.dayNumber}</span>
              </Button>
            ))}
          </div>
        </div>

        <div className="p-4 space-y-6">
          {/* Breakfast */}
          <div>
            <h2 className="text-lg font-medium mb-3">Breakfast</h2>
            {currentMeals.breakfast ? (
              <MealPlanCard
                meal={currentMeals.breakfast}
                recipe={getRecipeByTitle(currentMeals.breakfast.recipe)}
                onViewRecipe={() => {
                  setSelectedRecipe(getRecipeByTitle(currentMeals.breakfast.recipe));
                  setCurrentScreen('recipe');
                }}
              />
            ) : (
              <Card className="p-4 bg-white border-2 border-dashed border-gray-200">
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-2">
                    <Utensils className="w-12 h-12 mx-auto" />
                  </div>
                  <p className="text-gray-500 mb-3">No breakfast planned</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentScreen('search')}
                  >
                    Add Meal
                  </Button>
                </div>
              </Card>
            )}
          </div>

          {/* Lunch */}
          <div>
            <h2 className="text-lg font-medium mb-3">Lunch</h2>
            {currentMeals.lunch ? (
              <MealPlanCard
                meal={currentMeals.lunch}
                recipe={getRecipeByTitle(currentMeals.lunch.recipe)}
                onViewRecipe={() => {
                  setSelectedRecipe(getRecipeByTitle(currentMeals.lunch.recipe));
                  setCurrentScreen('recipe');
                }}
              />
            ) : (
              <Card className="p-4 bg-white border-2 border-dashed border-gray-200">
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-2">
                    <Utensils className="w-12 h-12 mx-auto" />
                  </div>
                  <p className="text-gray-500 mb-3">No lunch planned</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentScreen('search')}
                  >
                    Add Meal
                  </Button>
                </div>
              </Card>
            )}
          </div>

          {/* Dinner */}
          <div>
            <h2 className="text-lg font-medium mb-3">Dinner</h2>
            {currentMeals.dinner ? (
              <MealPlanCard
                meal={currentMeals.dinner}
                recipe={getRecipeByTitle(currentMeals.dinner.recipe)}
                onViewRecipe={() => {
                  setSelectedRecipe(getRecipeByTitle(currentMeals.dinner.recipe));
                  setCurrentScreen('recipe');
                }}
              />
            ) : (
              <Card className="p-4 bg-white border-2 border-dashed border-gray-200">
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-2">
                    <Utensils className="w-12 h-12 mx-auto" />
                  </div>
                  <p className="text-gray-500 mb-3">No dinner planned</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentScreen('search')}
                  >
                    Add Meal
                  </Button>
                </div>
              </Card>
            )}
          </div>
        </div>

        <BottomNavigation current="mealplan" onNavigate={setCurrentScreen} />
      </div>
    );
  };
  
  const CalendarScreen = () => (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <Button variant="ghost" size="sm" className="rounded-full w-10 h-10 p-0 bg-green-100">
          <ChevronLeft className="h-5 w-5 text-green-600" />
        </Button>
        <h1 className="text-lg font-medium">{monthName}</h1>
        <Avatar className="w-10 h-10">
          <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b814?w=40&h=40&fit=crop&crop=face" />
          <AvatarFallback>E</AvatarFallback>
        </Avatar>
      </div>

      {/* Calendar Grid */}
      <div className="p-4">
        <div className="grid grid-cols-7 gap-2 mb-6">
          {['Su', 'Mo', 'Tue', 'We', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div key={day} className="text-center text-gray-500 text-sm py-2">
              {day}
            </div>
          ))}
          {[2, 1, 2, 3, 4, 5, 6].map((date, index) => (
            <div key={index} className="text-center py-3">
              <Button
                variant="ghost"
                size="sm"
                className={`w-8 h-8 p-0 rounded-full ${
                  date === 1 ? 'bg-green-100 text-green-600' : 
                  date === 2 || date === 3 ? 'bg-blue-50 text-blue-600' : 
                  'text-gray-800 hover:bg-gray-100'
                }`}
                onClick={() => {
                  if (date === 2 || date === 3) {
                    setSelectedDate(`2025-01-0${date}`);
                    setCurrentScreen('mealplan');
                  }
                }}
              >
                {date}
              </Button>
              {/* Meal indicators */}
              {(date === 2 || date === 3) && (
                <div className="flex justify-center gap-1 mt-1">
                  <div className="w-1 h-1 bg-green-400 rounded-full"></div>
                  <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
                  <div className="w-1 h-1 bg-orange-400 rounded-full"></div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Tasks */}
        <div className="space-y-4">
          <TaskCard
            title="Meal planning"
            subtitle="Research recipes for family meals"
            time="Tomorrow's meal plan at 9:00 AM"
            icon="📅"
          />
          <TaskCard
            title="Log food intake"
            subtitle="Track your meals now."
            time="Tomorrow's meal plan at 9:00 AM"
            icon="📋"
          />
          <TaskCard
            title="Prepare dinner menu"
            subtitle=""
            time="Today's meal prep at 2:00 PM"
            icon="🍽️"
          />
          <TaskCard
            title="Check meal reservations"
            subtitle="Confirm dinner bookings."
            time="Tomorrow's meal plan at 9:00 AM"
            icon="📅"
          />
        </div>
      </div>

      <BottomNavigation current="calendar" onNavigate={setCurrentScreen} />
    </div>
  );

  const RecipeSearchScreen = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm" 
            className="rounded-full w-10 h-10 p-0"
            onClick={() => setCurrentScreen('meals')}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-medium">Find Recipes</h1>
        </div>
        <Button variant="ghost" size="sm">
          <Filter className="w-5 h-5" />
        </Button>
      </div>

      <div className="p-4">
        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search recipes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Filters */}
        <div className="flex gap-3 mb-6">
          <Select value={selectedCuisine} onValueChange={setSelectedCuisine}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Cuisine" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Cuisines</SelectItem>
              <SelectItem value="mediterranean">Mediterranean</SelectItem>
              <SelectItem value="asian">Asian</SelectItem>
              <SelectItem value="american">American</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedDiet} onValueChange={setSelectedDiet}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Diet" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Diets</SelectItem>
              <SelectItem value="vegetarian">Vegetarian</SelectItem>
              <SelectItem value="vegan">Vegan</SelectItem>
              <SelectItem value="high-protein">High Protein</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Cook Time Filter */}
        <div className="mb-6">
          <label className="text-sm font-medium mb-2 block">Max Cook Time: {maxCookTime} mins</label>
          <input
            type="range"
            min="10"
            max="120"
            step="5"
            value={maxCookTime}
            onChange={(e) => setMaxCookTime(e.target.value)}
            className="w-full"
          />
        </div>

        {/* Recipe Results */}
        <div className="space-y-4">
          {filterRecipes().map(recipe => (
            <Card key={recipe.id} className="p-4 bg-white">
              <div className="flex gap-3">
                <ImageWithFallback
                  src={recipe.image}
                  alt={recipe.title}
                  className="w-20 h-20 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium">{recipe.title}</h3>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm text-gray-600">{recipe.rating}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-2 line-clamp-2">{recipe.description}</p>
                  <div className="flex gap-4 text-xs text-gray-500 mb-3">
                    <span className="flex items-center gap-1">
                      <Timer className="w-3 h-3" />
                      {recipe.cookTime}m
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {recipe.servings}
                    </span>
                    <span>{recipe.calories} cal</span>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="secondary" className="text-xs">{recipe.cuisine}</Badge>
                    <Badge variant="outline" className="text-xs">{recipe.diet}</Badge>
                  </div>
                </div>
              </div>
              <Button 
                className="w-full mt-3 bg-green-600 hover:bg-green-700"
                onClick={() => {
                  setSelectedRecipe(recipe);
                  setCurrentScreen('recipe');
                }}
              >
                View Recipe
              </Button>
            </Card>
          ))}
        </div>
      </div>

      <BottomNavigation current="search" onNavigate={setCurrentScreen} />
    </div>
  );

  const NutritionScreen = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm" 
            className="rounded-full w-10 h-10 p-0"
            onClick={() => setCurrentScreen('meals')}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-medium">Nutrition Tracking</h1>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => setCurrentScreen('preferences')}
        >
          <Settings className="w-5 h-5" />
        </Button>
      </div>

      <div className="p-4">
        {/* Daily Overview */}
        <Card className="p-4 mb-6 bg-white">
          <h3 className="font-medium mb-4">Today's Progress</h3>
          <div className="space-y-4">
            <NutritionItem 
              label="Calories" 
              current={nutritionProgress.calories} 
              goal={nutritionGoals.calories}
              unit="kcal"
              color="bg-blue-500"
            />
            <NutritionItem 
              label="Protein" 
              current={nutritionProgress.protein} 
              goal={nutritionGoals.protein}
              unit="g"
              color="bg-green-500"
            />
            <NutritionItem 
              label="Carbs" 
              current={nutritionProgress.carbs} 
              goal={nutritionGoals.carbs}
              unit="g"
              color="bg-yellow-500"
            />
            <NutritionItem 
              label="Fat" 
              current={nutritionProgress.fat} 
              goal={nutritionGoals.fat}
              unit="g"
              color="bg-purple-500"
            />
            <NutritionItem 
              label="Fiber" 
              current={nutritionProgress.fiber} 
              goal={nutritionGoals.fiber}
              unit="g"
              color="bg-orange-500"
            />
          </div>
        </Card>

        {/* Weekly Progress */}
        <Card className="p-4 mb-6 bg-white">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">Weekly Summary</h3>
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <p className="text-2xl font-medium text-green-600">6/7</p>
              <p className="text-sm text-gray-600">Goals Met</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-medium text-blue-600">1,850</p>
              <p className="text-sm text-gray-600">Avg Calories</p>
            </div>
          </div>
        </Card>

        {/* Quick Add */}
        <Card className="p-4 bg-white">
          <h3 className="font-medium mb-4">Quick Add Meal</h3>
          <div className="grid grid-cols-3 gap-3">
            <Button variant="outline" className="flex flex-col h-16">
              <span className="text-lg mb-1">🍳</span>
              <span className="text-xs">Breakfast</span>
            </Button>
            <Button variant="outline" className="flex flex-col h-16">
              <span className="text-lg mb-1">🥗</span>
              <span className="text-xs">Lunch</span>
            </Button>
            <Button variant="outline" className="flex flex-col h-16">
              <span className="text-lg mb-1">🍽️</span>
              <span className="text-xs">Dinner</span>
            </Button>
          </div>
        </Card>
      </div>

      <BottomNavigation current="nutrition" onNavigate={setCurrentScreen} />
    </div>
  );

  const MealScheduleScreen = () => {
    const date = selectedDate || '2025-01-02';
    const dayMeals = mealSchedule[date] || { breakfast: null, lunch: null, dinner: null };

    return (
      <div className="min-h-screen bg-white">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <Button 
            variant="ghost" 
            size="sm" 
            className="rounded-full w-10 h-10 p-0"
            onClick={() => setCurrentScreen('calendar')}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-medium">
            {new Date(date).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
          </h1>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-4">
          {/* Meals for the day */}
          <div className="space-y-6">
            <MealSlot
              mealType="Breakfast"
              emoji="🍳"
              meal={dayMeals.breakfast?.recipe}
              onAddMeal={() => setCurrentScreen('search')}
            />
            <MealSlot
              mealType="Lunch"
              emoji="🥗"
              meal={dayMeals.lunch?.recipe}
              onAddMeal={() => setCurrentScreen('search')}
            />
            <MealSlot
              mealType="Dinner"
              emoji="🍽️"
              meal={dayMeals.dinner?.recipe}
              onAddMeal={() => setCurrentScreen('search')}
            />
          </div>

          {/* Daily nutrition summary */}
          <Card className="p-4 mt-6 bg-gray-50">
            <h3 className="font-medium mb-3">Planned Nutrition</h3>
            <div className="grid grid-cols-4 gap-3 text-center">
              <div>
                <p className="text-lg font-medium">
                  {(dayMeals.breakfast?.calories || 0) + 
                   (dayMeals.lunch?.calories || 0) + 
                   (dayMeals.dinner?.calories || 0)}
                </p>
                <p className="text-xs text-gray-600">Calories</p>
              </div>
              <div>
                <p className="text-lg font-medium">28g</p>
                <p className="text-xs text-gray-600">Protein</p>
              </div>
              <div>
                <p className="text-lg font-medium">82g</p>
                <p className="text-xs text-gray-600">Carbs</p>
              </div>
              <div>
                <p className="text-lg font-medium">21g</p>
                <p className="text-xs text-gray-600">Fat</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  };

  const PreferencesScreen = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm" 
            className="rounded-full w-10 h-10 p-0"
            onClick={() => setCurrentScreen('nutrition')}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-medium">Dietary Preferences</h1>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Dietary Restrictions */}
        <Card className="p-4 bg-white">
          <h3 className="font-medium mb-4">Dietary Restrictions</h3>
          <div className="space-y-3">
            {['Vegetarian', 'Vegan', 'Gluten-Free', 'Dairy-Free', 'Keto'].map(diet => (
              <div key={diet} className="flex items-center justify-between">
                <span>{diet}</span>
                <Switch 
                  checked={userPreferences.dietaryRestrictions.includes(diet.toLowerCase())}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setUserPreferences(prev => ({
                        ...prev,
                        dietaryRestrictions: [...prev.dietaryRestrictions, diet.toLowerCase()]
                      }));
                    } else {
                      setUserPreferences(prev => ({
                        ...prev,
                        dietaryRestrictions: prev.dietaryRestrictions.filter(d => d !== diet.toLowerCase())
                      }));
                    }
                  }}
                />
              </div>
            ))}
          </div>
        </Card>

        {/* Allergies */}
        <Card className="p-4 bg-white">
          <h3 className="font-medium mb-4">Allergies</h3>
          <div className="space-y-3">
            {['Nuts', 'Shellfish', 'Eggs', 'Soy', 'Fish'].map(allergy => (
              <div key={allergy} className="flex items-center justify-between">
                <span>{allergy}</span>
                <Switch 
                  checked={userPreferences.allergies.includes(allergy.toLowerCase())}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setUserPreferences(prev => ({
                        ...prev,
                        allergies: [...prev.allergies, allergy.toLowerCase()]
                      }));
                    } else {
                      setUserPreferences(prev => ({
                        ...prev,
                        allergies: prev.allergies.filter(a => a !== allergy.toLowerCase())
                      }));
                    }
                  }}
                />
              </div>
            ))}
          </div>
        </Card>

        {/* Nutrition Goals */}
        <Card className="p-4 bg-white">
          <h3 className="font-medium mb-4">Daily Nutrition Goals</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Daily Calories</label>
              <Input
                type="number"
                value={nutritionGoals.calories}
                onChange={(e) => setNutritionGoals(prev => ({ ...prev, calories: parseInt(e.target.value) }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Protein (g)</label>
              <Input
                type="number"
                value={nutritionGoals.protein}
                onChange={(e) => setNutritionGoals(prev => ({ ...prev, protein: parseInt(e.target.value) }))}
              />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  const AIAssistantScreen = ({ isPopup = false }) => (
    <div className={`min-h-screen bg-gray-50 ${isPopup ? 'relative' : ''}`}>
      {/* Status Bar - only show if not popup */}
      {!isPopup && (
        <div className="flex justify-between items-center p-4 text-sm">
          <span>9:41</span>
          <div className="flex items-center gap-1">
            <div className="flex gap-1">
              <div className="w-1 h-3 bg-black rounded-full"></div>
              <div className="w-1 h-3 bg-black rounded-full"></div>
              <div className="w-1 h-3 bg-black rounded-full"></div>
              <div className="w-1 h-3 bg-gray-300 rounded-full"></div>
            </div>
            <span className="ml-2">📶</span>
            <span>🔋</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          {isPopup ? (
            <Button 
              variant="ghost" 
              size="sm" 
              className="rounded-full w-10 h-10 p-0"
              onClick={() => setIsAIPopupOpen(false)}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          ) : (
            <Home className="w-6 h-6" />
          )}
        </div>
        <Avatar className="w-12 h-12">
          <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b814?w=48&h=48&fit=crop&crop=face" />
          <AvatarFallback>E</AvatarFallback>
        </Avatar>
      </div>

      {/* AI Assistant Content */}
      <div className="px-4 pb-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-medium mb-2">Savvi</h2>
          <p className="text-gray-600">Your AI Assistant</p>
        </div>

        <div className="text-center mb-8">
          <h3 className="text-3xl font-medium mb-2">Hello Ella!</h3>
          <p className="text-gray-600">I'm listening...</p>
        </div>

        {/* Voice Waveform */}
        <div className="flex justify-center items-end h-32 mb-8 gap-1">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className={`bg-gradient-to-t from-blue-400 to-red-400 ${isRecording ? 'opacity-90 animate-pulse' : 'opacity-30'}`}
              style={{
                width: '2px',
                height: `${isRecording ? Math.random() * 100 + 40 : Math.random() * 20 + 10}px`,
                borderRadius: '1px',
                transition: 'all 0.3s ease'
              }}
            />
          ))}
        </div>

        {/* Voice Instructions */}
        <div className="mb-4 text-center">
          <p className="text-gray-600 text-sm mb-1">🎤 Tap and hold to speak</p>
          <p className="text-gray-500 text-xs">
            Try: "Add salmon to grocery list" or "What's for dinner?"
          </p>
        </div>

        {/* AI Response */}
        {isRecording && (
          <div className="mb-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
            <p className="text-blue-800 text-sm">
              🎤 Listening... Say something like "Add chicken to my grocery list" or "What's for dinner tomorrow?"
            </p>
          </div>
        )}

        {!isRecording && (
          <div className="mb-6 p-4 bg-green-50 rounded-lg border-l-4 border-green-400">
            <p className="text-green-800 font-medium text-sm mb-1">Savvi says:</p>
            <p className="text-green-700 text-sm">
              "I've added grilled chicken to your grocery list and scheduled your meal prep for tomorrow at 2 PM!"
            </p>
          </div>
        )}

        {/* Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <Button 
            variant="outline" 
            className="h-20 bg-white flex flex-col items-center justify-center p-4 border-2"
            onClick={() => {
              if (isPopup) {
                setIsAIPopupOpen(false);
                setCurrentScreen('meals');
              } else {
                setCurrentScreen('meals');
              }
            }}
          >
            <Utensils className="w-6 h-6 mb-2 text-purple-600" />
            <span className="text-sm font-medium text-center">Recipes &<br />Meal Plans</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-20 bg-white flex flex-col items-center justify-center p-4 border-2"
            onClick={() => {
              if (isPopup) {
                setIsAIPopupOpen(false);
                setCurrentScreen('grocery');
              } else {
                setCurrentScreen('grocery');
              }
            }}
          >
            <ShoppingCart className="w-6 h-6 mb-2 text-blue-600" />
            <span className="text-sm font-medium text-center">Order<br />Groceries</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-20 bg-white flex flex-col items-center justify-center p-4 border-2"
            onClick={() => {
              if (isPopup) {
                setIsAIPopupOpen(false);
                setCurrentScreen('search');
              } else {
                setCurrentScreen('search');
              }
            }}
          >
            <Scan className="w-6 h-6 mb-2 text-orange-600" />
            <span className="text-sm font-medium text-center">Pantry<br />Scan</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-20 bg-white flex flex-col items-center justify-center p-4 border-2"
            onClick={() => {
              if (isPopup) {
                setIsAIPopupOpen(false);
                setCurrentScreen('meals');
              } else {
                setCurrentScreen('meals');
              }
            }}
          >
            <Truck className="w-6 h-6 mb-2 text-red-600" />
            <span className="text-sm font-medium text-center">Order<br />Takeout</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-20 bg-white flex flex-col items-center justify-center p-4 border-2"
            onClick={() => {
              if (isPopup) {
                setIsAIPopupOpen(false);
                setCurrentScreen('nutrition');
              } else {
                setCurrentScreen('nutrition');
              }
            }}
          >
            <Heart className="w-6 h-6 mb-2 text-pink-600" />
            <span className="text-sm font-medium text-center">Daily<br />Wellness</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-20 bg-white flex flex-col items-center justify-center p-4 border-2"
            onClick={() => {
              if (isPopup) {
                setIsAIPopupOpen(false);
                setCurrentScreen('calendar');
              } else {
                setCurrentScreen('calendar');
              }
            }}
          >
            <Calendar className="w-6 h-6 mb-2 text-indigo-600" />
            <span className="text-sm font-medium text-center">Calendar</span>
          </Button>
        </div>

        {/* Text Input Area */}
        <div className="mb-6 p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-lg">💬</span>
            <span className="text-sm font-medium text-gray-700">Type your question</span>
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Ask me anything about your meals..."
              value={aiTextInput}
              onChange={(e) => setAiTextInput(e.target.value)}
              className="flex-1 border border-gray-200 rounded-lg px-3 py-3 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              onKeyPress={(e) => {
                if (e.key === 'Enter' && aiTextInput.trim()) {
                  // Handle sending text message
                  console.log('Sending text:', aiTextInput);
                  setAiTextInput('');
                }
              }}
            />
            <Button 
              className="rounded-lg px-4 py-3 bg-purple-500 hover:bg-purple-600 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={!aiTextInput.trim()}
              onClick={() => {
                if (aiTextInput.trim()) {
                  // Handle sending text message
                  console.log('Sending text:', aiTextInput);
                  setAiTextInput('');
                }
              }}
            >
              <Send className="w-4 h-4 text-white" />
            </Button>
          </div>
        </div>

        {/* Divider */}
        <div className="relative mb-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-3 bg-gray-50 text-gray-500">or use voice</span>
          </div>
        </div>

        {/* Voice Button Area */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <div className="flex justify-center items-center gap-4">
            <Button variant="outline" size="sm" className="rounded-full w-12 h-12 p-0">
              <Clock className="w-5 h-5" />
            </Button>
            <Button 
              className={`rounded-full w-20 h-20 p-0 shadow-lg transition-all duration-200 ${
                isRecording 
                  ? 'bg-red-500 hover:bg-red-600 animate-pulse scale-105' 
                  : 'bg-purple-500 hover:bg-purple-600 hover:scale-105'
              }`}
              onClick={() => setIsRecording(!isRecording)}
            >
              <Mic className="w-8 h-8 text-white" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="rounded-full w-12 h-12 p-0"
              onClick={() => {
                if (isPopup) {
                  setIsAIPopupOpen(false);
                  setCurrentScreen('grocery');
                } else {
                  setCurrentScreen('grocery');
                }
              }}
            >
              <ShoppingCart className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom Navigation - only show if not popup */}
      {!isPopup && <BottomNavigation current="ai" onNavigate={setCurrentScreen} />}
    </div>
  );

  const MealPlansScreen = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className="text-purple-600">🥗</span>
          <span className="font-medium">Savvi</span>
        </div>
        <Avatar className="w-8 h-8">
          <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b814?w=32&h=32&fit=crop&crop=face" />
          <AvatarFallback>E</AvatarFallback>
        </Avatar>
      </div>

      <div className="p-4">
        <h2 className="text-xl font-medium mb-6">Your Meal Plans</h2>

        {/* Quick Actions */}
        <div className="flex gap-3 mb-6">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => setCurrentScreen('search')}
          >
            <Search className="w-4 h-4 mr-2" />
            Find Recipes
          </Button>
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => setCurrentScreen('calendar')}
          >
            <Calendar className="w-4 h-4 mr-2" />
            Calendar
          </Button>
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => setCurrentScreen('nutrition')}
          >
            <Target className="w-4 h-4 mr-2" />
            Nutrition
          </Button>
        </div>

        {/* Meal Cards */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {allRecipes.slice(0, 3).map(recipe => (
            <MealCard
              key={recipe.id}
              image={recipe.image}
              title={recipe.title}
              description={recipe.description}
              rating={recipe.rating}
              cookTime={recipe.cookTime}
              onViewRecipe={() => {
                setSelectedRecipe(recipe);
                setCurrentScreen('recipe');
              }}
            />
          ))}
        </div>

        {/* Upcoming Tasks */}
        <div>
          <h3 className="text-lg font-medium mb-4">Upcoming Family Tasks</h3>
          <div className="space-y-3">
            <TaskItem
              title="Doctor's Appointment"
              time="Tomorrow at 10:00 AM"
            />
            <TaskItem
              title="Family Picnic"
              time="Saturday at 2:00 PM"
            />
            <TaskItem
              title="Grocery Shopping"
              time="Sunday at 4:00 PM"
            />
          </div>
        </div>
      </div>

      <BottomNavigation current="meals" onNavigate={setCurrentScreen} />
    </div>
  );

  const RecipeDetailScreen = () => (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="relative">
        <ImageWithFallback
          src={selectedRecipe?.image}
          alt={selectedRecipe?.title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
          <Button 
            variant="ghost" 
            size="sm" 
            className="rounded-full w-10 h-10 p-0 bg-white/80 backdrop-blur-sm"
            onClick={() => setCurrentScreen('meals')}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" className="rounded-full w-10 h-10 p-0 bg-white/80 backdrop-blur-sm">
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full w-10 h-10 p-0 bg-white/80 backdrop-blur-sm">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4">
        <h1 className="text-2xl font-medium mb-2">{selectedRecipe?.title}</h1>
        <p className="text-gray-600 mb-4">{selectedRecipe?.description}</p>

        {/* Recipe Stats */}
        <div className="flex justify-between items-center mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="text-center">
            <Timer className="w-5 h-5 mx-auto mb-1 text-green-600" />
            <p className="text-sm text-gray-600">Cook Time</p>
            <p className="font-medium">{selectedRecipe?.cookTime}m</p>
          </div>
          <div className="text-center">
            <Users className="w-5 h-5 mx-auto mb-1 text-green-600" />
            <p className="text-sm text-gray-600">Servings</p>
            <p className="font-medium">{selectedRecipe?.servings}</p>
          </div>
          <div className="text-center">
            <span className="text-lg mx-auto mb-1 block">🔥</span>
            <p className="text-sm text-gray-600">Calories</p>
            <p className="font-medium">{selectedRecipe?.calories}</p>
          </div>
        </div>

        {/* Nutrition Info */}
        <Card className="p-4 mb-6 bg-blue-50 border-blue-200">
          <h3 className="font-medium mb-3">Nutrition per serving</h3>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="font-medium text-green-600">{selectedRecipe?.protein}g</p>
              <p className="text-xs text-gray-600">Protein</p>
            </div>
            <div>
              <p className="font-medium text-yellow-600">{selectedRecipe?.carbs}g</p>
              <p className="text-xs text-gray-600">Carbs</p>
            </div>
            <div>
              <p className="font-medium text-purple-600">{selectedRecipe?.fat}g</p>
              <p className="text-xs text-gray-600">Fat</p>
            </div>
          </div>
        </Card>

        {/* Ingredients */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-lg font-medium">Ingredients</h3>
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => setCurrentScreen('grocery')}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add to List
            </Button>
          </div>
          <div className="space-y-2">
            {selectedRecipe?.ingredients.map((ingredient, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span>{ingredient}</span>
                <Button variant="ghost" size="sm" className="p-0 w-6 h-6">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Instructions */}
        <div className="mb-20">
          <h3 className="text-lg font-medium mb-3">Instructions</h3>
          <div className="space-y-4">
            {selectedRecipe?.instructions.map((instruction, index) => (
              <div key={index} className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-medium">
                  {index + 1}
                </div>
                <p className="flex-1 pt-1">{instruction}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const GroceryListScreen = () => {
    const toggleGroceryItem = (id) => {
      setGroceryList(prev => prev.map(item => 
        item.id === id ? { ...item, checked: !item.checked } : item
      ));
    };

    const categories = [...new Set(groceryList.map(item => item.category))];

    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm" 
              className="rounded-full w-10 h-10 p-0"
              onClick={() => setCurrentScreen('meals')}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">Grocery List</h1>
          </div>
          <Button size="sm" className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Item
          </Button>
        </div>

        {/* Progress */}
        <div className="p-4 bg-white border-b border-gray-100">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">Shopping Progress</span>
            <span className="text-sm font-medium">
              {groceryList.filter(item => item.checked).length} / {groceryList.length}
            </span>
          </div>
          <Progress 
            value={(groceryList.filter(item => item.checked).length / groceryList.length) * 100} 
            className="h-2"
          />
        </div>

        <div className="p-4">
          {categories.map(category => (
            <div key={category} className="mb-6">
              <h3 className="text-lg font-medium mb-3 text-gray-800">{category}</h3>
              <div className="space-y-2">
                {groceryList
                  .filter(item => item.category === category)
                  .map(item => (
                    <Card key={item.id} className="p-3 bg-white">
                      <div className="flex items-center gap-3">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="p-0 w-6 h-6"
                          onClick={() => toggleGroceryItem(item.id)}
                        >
                          {item.checked ? (
                            <CheckSquare className="w-5 h-5 text-green-600" />
                          ) : (
                            <Square className="w-5 h-5 text-gray-400" />
                          )}
                        </Button>
                        <div className="flex-1">
                          <p className={`font-medium ${item.checked ? 'line-through text-gray-500' : ''}`}>
                            {item.name}
                          </p>
                          <p className="text-sm text-gray-500">{item.quantity}</p>
                        </div>
                        <Button variant="ghost" size="sm" className="p-0 w-6 h-6">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
              </div>
            </div>
          ))}
        </div>

        <BottomNavigation current="grocery" onNavigate={setCurrentScreen} />
      </div>
    );
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'calendar':
        return <CalendarScreen />;
      case 'ai':
        return <AIAssistantScreen />;
      case 'meals':
        return <MealPlansScreen />;
      case 'mealplan':
        return <DailyMealPlanScreen />;
      case 'recipe':
        return <RecipeDetailScreen />;
      case 'grocery':
        return <GroceryListScreen />;
      case 'search':
        return <RecipeSearchScreen />;
      case 'nutrition':
        return <NutritionScreen />;
      case 'schedule':
        return <MealScheduleScreen />;
      case 'preferences':
        return <PreferencesScreen />;
      default:
        return <CalendarScreen />;
    }
  };

  // Screens that should show the floating microphone button
  const screensWithFloatingMic = ['calendar', 'grocery', 'meals', 'mealplan'];
  const shouldShowFloatingMic = screensWithFloatingMic.includes(currentScreen);

  // Handle escape key to close AI popup
  React.useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isAIPopupOpen) {
        setIsAIPopupOpen(false);
      }
    };
    
    if (isAIPopupOpen) {
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }
  }, [isAIPopupOpen]);

  return (
    <div className="max-w-sm mx-auto bg-white min-h-screen relative">
      {renderScreen()}
      
      {/* Floating Microphone Button */}
      {shouldShowFloatingMic && !isAIPopupOpen && (
        <FloatingMicButton onClick={() => setIsAIPopupOpen(true)} />
      )}
      
      {/* AI Assistant Popup Overlay */}
      {isAIPopupOpen && (
        <div 
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setIsAIPopupOpen(false);
            }
          }}
        >
          <div className="absolute inset-0 max-w-sm mx-auto">
            <AIAssistantScreen isPopup={true} />
          </div>
        </div>
      )}
    </div>
  );
}

const TaskCard = ({ title, subtitle, time, icon }) => (
  <Card className="p-4 bg-white border border-gray-100">
    <CardContent className="p-0">
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-medium">{title}</h3>
        <MoreHorizontal className="w-5 h-5 text-gray-400" />
      </div>
      {subtitle && (
        <p className="text-gray-600 text-sm mb-2">{subtitle}</p>
      )}
      <div className="flex items-center text-gray-500 text-sm">
        <span className="mr-2">📅</span>
        <span>{time}</span>
      </div>
    </CardContent>
  </Card>
);

const MealCard = ({ image, title, description, rating, cookTime, onViewRecipe }) => (
  <Card className="overflow-hidden bg-white">
    <div className="aspect-square relative">
      <ImageWithFallback
        src={image}
        alt={title}
        className="w-full h-full object-cover"
      />
      {rating && (
        <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 flex items-center gap-1">
          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
          <span className="text-xs font-medium">{rating}</span>
        </div>
      )}
    </div>
    <CardContent className="p-3">
      <h4 className="font-medium text-sm mb-1">{title}</h4>
      <p className="text-xs text-gray-600 mb-2 line-clamp-2">{description}</p>
      {cookTime && (
        <p className="text-xs text-gray-500 mb-3 flex items-center gap-1">
          <Timer className="w-3 h-3" />
          {cookTime} mins
        </p>
      )}
      <Button 
        size="sm" 
        className="w-full bg-green-600 hover:bg-green-700 text-xs"
        onClick={onViewRecipe}
      >
        View Recipe
      </Button>
    </CardContent>
  </Card>
);

const TaskItem = ({ title, time }) => (
  <Card className="p-4 bg-white border border-gray-100">
    <CardContent className="p-0">
      <h4 className="font-medium text-sm mb-1">{title}</h4>
      <p className="text-gray-500 text-xs">{time}</p>
    </CardContent>
  </Card>
);

const NutritionItem = ({ label, current, goal, unit, color }) => (
  <div>
    <div className="flex justify-between items-center mb-2">
      <span className="font-medium">{label}</span>
      <span className="text-sm text-gray-600">
        {current} / {goal} {unit}
      </span>
    </div>
    <div className="w-full bg-gray-200 rounded-full h-2">
      <div 
        className={color.startsWith('#') ? 'h-2 rounded-full' : `h-2 rounded-full ${color}`}
        style={{ 
          width: `${Math.min((current / goal) * 100, 100)}%`,
          backgroundColor: color.startsWith('#') ? color : undefined
        }}
      />
    </div>
  </div>
);

const MealSlot = ({ mealType, emoji, meal, onAddMeal }) => (
  <Card className="p-4 bg-white">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <span className="text-2xl">{emoji}</span>
        <div>
          <h3 className="font-medium">{mealType}</h3>
          {meal ? (
            <p className="text-sm text-gray-600">{meal}</p>
          ) : (
            <p className="text-sm text-gray-400">No meal planned</p>
          )}
        </div>
      </div>
      <Button 
        variant={meal ? "outline" : "default"}
        size="sm"
        onClick={onAddMeal}
        className={meal ? "" : "bg-green-600 hover:bg-green-700"}
      >
        {meal ? "Change" : "Add Meal"}
      </Button>
    </div>
  </Card>
);

const MealPlanCard = ({ meal, recipe, onViewRecipe }) => (
  <Card className="bg-white overflow-hidden">
    <div className="flex">
      <div className="w-20 h-20 flex-shrink-0">
        <ImageWithFallback
          src={recipe.image}
          alt={recipe.title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex-1 p-4">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="font-medium text-sm mb-1">{recipe.title}</h3>
            <p className="text-sm text-gray-600">{meal.calories} cal</p>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1 h-auto"
            onClick={onViewRecipe}
          >
            <ChevronRight className="w-4 h-4 text-gray-400" />
          </Button>
        </div>
      </div>
    </div>
  </Card>
);

const FloatingMicButton = ({ onClick }) => (
  <Button
    className="fixed bottom-20 right-4 w-14 h-14 rounded-full bg-purple-500 hover:bg-purple-600 shadow-lg z-40 p-0 transition-all duration-200 hover:scale-105"
    onClick={onClick}
  >
    <Mic className="w-6 h-6 text-white" />
  </Button>
);

const BottomNavigation = ({ current, onNavigate }) => (
  <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm bg-white border-t border-gray-200">
    <div className="flex justify-around py-2">
      <Button
        variant="ghost"
        size="sm"
        className="flex flex-col items-center p-3"
        onClick={() => onNavigate('home')}
      >
        <Home className={`w-6 h-6 mb-1 ${current === 'home' ? 'text-green-600' : 'text-gray-400'}`} />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="flex flex-col items-center p-3"
        onClick={() => onNavigate('calendar')}
      >
        <Calendar className={`w-6 h-6 mb-1 ${current === 'calendar' || current === 'mealplan' ? 'text-green-600' : 'text-gray-400'}`} />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="flex flex-col items-center p-3"
        onClick={() => onNavigate('ai')}
      >
        <Mic className={`w-6 h-6 mb-1 ${current === 'ai' ? 'text-green-600' : 'text-gray-400'}`} />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="flex flex-col items-center p-3"
        onClick={() => onNavigate('grocery')}
      >
        <ShoppingCart className={`w-6 h-6 mb-1 ${current === 'grocery' ? 'text-green-600' : 'text-gray-400'}`} />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="flex flex-col items-center p-3"
        onClick={() => onNavigate('meals')}
      >
        <Utensils className={`w-6 h-6 mb-1 ${current === 'meals' ? 'text-green-600' : 'text-gray-400'}`} />
      </Button>
    </div>
  </div>
);