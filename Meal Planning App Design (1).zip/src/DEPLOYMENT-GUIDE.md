# Savvi Deployment Guide

## ❓ Do I need to connect GitHub to Figma?

**No!** You don't need to connect GitHub to Figma. Here's how the process works:

1. **Figma Make** → You build your app here (which you've already done!)
2. **Download/Copy Code** → You copy your app code to your local computer
3. **Local Development** → You set up the project locally with `npm install`
4. **GitHub Repository** → You push your code to your GitHub repo
5. **GitHub Pages** → Automatically deploys your app (already configured!)

## 🚀 Step-by-Step Deployment Process

### Step 1: Set Up Your Local Environment

You need to have these installed on your computer:
- **Node.js** (version 18 or newer) - [Download here](https://nodejs.org/)
- **Git** - [Download here](https://git-scm.com/)
- **Code Editor** (like VS Code) - [Download here](https://code.visualstudio.com/)

### Step 2: Get Your Code Locally

**Option A: Download from Figma Make**
1. In Figma Make, look for an "Export" or "Download" button
2. Download your project as a ZIP file
3. Extract the ZIP to a folder on your computer

**Option B: Copy Files Manually**
1. Create a new folder on your computer called `savviwell-platform`
2. Copy all the files from Figma Make into this folder
3. Make sure you have all the files shown in your file structure

### Step 3: Install Dependencies

1. **Open Terminal/Command Prompt**
   - **Windows**: Search for "Command Prompt" or "PowerShell"
   - **Mac**: Search for "Terminal"
   - **Alternative**: Open your code editor and use its built-in terminal

2. **Navigate to your project folder**
   ```bash
   cd path/to/your/savviwell-platform
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

   This command:
   - Reads your `package.json` file
   - Downloads all required libraries (React, Tailwind, etc.)
   - Creates a `node_modules` folder with all dependencies

### Step 4: Test Locally

```bash
npm start
```

This will:
- Start a development server
- Open your app in a browser at `http://localhost:3000`
- Let you see your Savvi app running locally!

### Step 5: Connect to Your GitHub Repository

```bash
# Initialize git (if not already done)
git init

# Add your remote repository
git remote add origin https://github.com/co2030/savviwell-platform.git

# Add all files
git add .

# Commit your changes
git commit -m "Initial deployment of Savvi meal planning app"

# Push to GitHub
git push -u origin main
```

### Step 6: Automatic Deployment

Once you push to GitHub:
1. **GitHub Actions** automatically triggers (because of the workflow file)
2. It runs `npm install` and `npm run build` on GitHub's servers
3. Deploys your app to **https://co2030.github.io/savviwell-platform/**
4. Usually takes 2-5 minutes to complete

## 🔧 Project Structure Explanation

```
savviwell-platform/
├── package.json          # Dependencies and scripts
├── vite.config.ts        # Build configuration
├── index.html           # Entry HTML file
├── src/main.tsx         # React entry point
├── App.tsx              # Your main app component
├── components/          # Reusable UI components
├── styles/              # CSS and styling
└── .github/workflows/   # Auto-deployment configuration
```

## 🚨 Troubleshooting

### "npm is not recognized" Error
- Install Node.js from [nodejs.org](https://nodejs.org/)
- Restart your terminal after installation

### Permission Errors (Mac/Linux)
```bash
sudo npm install
```

### GitHub Push Issues
```bash
# If you get authentication errors, set up SSH keys or use personal access token
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### Deployment Not Working
1. Check the **Actions** tab in your GitHub repository
2. Look for any red X marks indicating failed builds
3. Click on the failed action to see error details

## 📱 What Happens After Deployment

Your Savvi app will be live at:
**https://co2030.github.io/savviwell-platform/**

Features that will work:
- ✅ Calendar view with meal planning
- ✅ Recipe search and filtering
- ✅ AI assistant interface
- ✅ Grocery list management
- ✅ Nutrition tracking
- ✅ Mobile-responsive design

## 🔄 Making Updates

After your initial deployment, updating is easy:

1. **Make changes** to your code locally
2. **Test changes**: `npm start`
3. **Deploy updates**:
   ```bash
   git add .
   git commit -m "Update meal planning features"
   git push
   ```
4. **Wait 2-5 minutes** for automatic deployment

## 🎯 Next Steps After Deployment

1. **Share your app** with friends and family
2. **Get feedback** on the user experience
3. **Add more features** like:
   - Recipe import from websites
   - Grocery store integration
   - Social sharing of meal plans
   - Calendar sync with Google/Apple

## 📞 Need Help?

If you run into issues:
1. Check this guide again
2. Look at the error messages carefully
3. Search for the error online
4. Ask for help with specific error messages

Your Savvi meal planning app is ready to help people eat healthier! 🥗✨